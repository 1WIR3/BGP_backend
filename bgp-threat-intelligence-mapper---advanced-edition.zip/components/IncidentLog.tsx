import React from 'react';
import { FeedEntryMessage } from '../types';

interface IncidentLogProps {
  incidentLogEntries: FeedEntryMessage[];
  clearIncidentLog: () => void;
}

const IncidentLog: React.FC<IncidentLogProps> = ({ incidentLogEntries, clearIncidentLog }) => {
  const getEntryStyle = (type: FeedEntryMessage['type']) => {
    switch(type) {
      case 'critical-alert': return 'text-red-700 border-l-red-600 bg-red-50 hover:bg-red-100';
      case 'error': return 'text-red-600 border-l-red-500 bg-red-50 hover:bg-red-100';
      case 'warning': return 'text-yellow-700 border-l-yellow-500 bg-yellow-50 hover:bg-yellow-100';
      default: return 'text-slate-700 border-l-slate-400 bg-slate-50'; // Should not be hit if filtered
    }
  };

  // Display newest incidents first
  const displayedEntries = [...incidentLogEntries].reverse();

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <i className="fas fa-archive text-orange-600"></i>
          Incident Log
        </h3>
        {displayedEntries.length > 0 && (
          <button
            onClick={clearIncidentLog}
            className="text-xs bg-slate-200 text-slate-700 hover:bg-slate-300 px-2.5 py-1.5 rounded-md transition-colors shadow-sm active:bg-slate-400"
            aria-label="Clear Incident Log"
          >
            <i className="fas fa-trash-alt mr-1.5"></i> Clear Log
          </button>
        )}
      </div>
      <div className="incident-log-entries analysis-panel max-h-80 overflow-y-auto p-1 rounded-md shadow-inner bg-slate-100/70" role="log" aria-live="polite" aria-atomic="false">
        {displayedEntries.length === 0 ? (
          <p className="text-sm text-slate-500 italic text-center py-4">No critical incidents or warnings logged.</p>
        ) : (
          displayedEntries.map((entry) => (
            <div 
                key={entry.id} 
                className={`p-2.5 mb-1.5 border-l-4 rounded-r-md transition-colors duration-150 ${getEntryStyle(entry.type)}`}
                role="listitem"
                aria-label={`${entry.type} at ${entry.timestamp}: ${entry.text}`}
            >
              <div className="flex justify-between items-center mb-0.5">
                <span className="font-semibold text-xs text-slate-700">
                    [{entry.timestamp}] - <span className={`font-bold ${entry.type === 'critical-alert' || entry.type === 'error' ? 'text-red-600' : 'text-yellow-600'}`}>{entry.type.toUpperCase().replace('-', ' ')}</span>
                </span>
              </div>
              <p className="text-xs text-slate-800 whitespace-pre-wrap font-mono">{entry.text}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default IncidentLog;
