
import React from 'react';
import { ASNDetailedInfo, ASNNode, RPKIStatus, KeyPeerInfo, RecentBGPActivityInfo } from '../types';
import { COUNTRY_FLAGS } from '../constants';

interface ASNDetailViewProps {
  detailData: ASNDetailedInfo | null;
  isLoading: boolean;
  onAnalyzeWithGemini: (asnId: string, dataToAnalyze: ASNDetailedInfo) => void;
  selectedASNInfo?: Pick<ASNNode, 'id' | 'name' | 'country' | 'org'> | null; // For consistent title
}

const getRPKIStatusVisuals = (status: RPKIStatus): { icon: string; color: string; text: string } => {
  switch (status) {
    case 'valid': return { icon: 'fas fa-check-circle', color: 'text-green-500', text: 'Valid' };
    case 'invalid': return { icon: 'fas fa-times-circle', color: 'text-red-500', text: 'Invalid' };
    case 'unknown': return { icon: 'fas fa-question-circle', color: 'text-yellow-500', text: 'Unknown' };
    case 'unverified':
    default: return { icon: 'fas fa-minus-circle', color: 'text-slate-400', text: 'Unverified' };
  }
};

const Section: React.FC<{ title: string; icon: string; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, icon, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = React.useState(defaultOpen);
  return (
    <div className="mb-3 bg-slate-50 p-3 rounded-lg shadow-sm">
      <button
        className="w-full flex justify-between items-center text-left text-sm font-semibold text-slate-700 mb-2 focus:outline-none"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
      >
        <span className="flex items-center gap-2">
          <i className={`${icon} ${isOpen ? 'text-blue-600' : 'text-slate-500'}`}></i> {title}
        </span>
        <i className={`fas ${isOpen ? 'fa-chevron-up' : 'fa-chevron-down'} text-slate-400`}></i>
      </button>
      {isOpen && <div className="text-xs space-y-2">{children}</div>}
    </div>
  );
};


const ASNDetailView: React.FC<ASNDetailViewProps> = ({ detailData, isLoading, onAnalyzeWithGemini, selectedASNInfo }) => {
  
  const panelTitle = detailData?.asn 
    ? (
        <>
          {COUNTRY_FLAGS[detailData.asn.country] || '🌐'} {detailData.asn.id} 
          <span className="font-normal text-gray-500 text-base hidden sm:inline"> ({detailData.asn.org})</span>
        </>
      )
    : selectedASNInfo ? ( // Fallback to selectedASNInfo if detailData is loading/null but an ASN is selected
        <>
         {COUNTRY_FLAGS[selectedASNInfo.country] || '🌐'} {selectedASNInfo.id} 
         <span className="font-normal text-gray-500 text-base hidden sm:inline"> ({selectedASNInfo.org})</span>
        </>
    )
    : "ASN Details";


  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
        <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <i className="fas fa-digital-tachograph text-blue-600 animate-pulse"></i>
          ASN Deep Dive: <span className="truncate max-w-[150px] sm:max-w-xs">{panelTitle}</span>
        </h3>
        <div className="flex items-center justify-center p-6 text-slate-500">
          <i className="fas fa-spinner fa-spin mr-2"></i> Loading detailed ASN information...
        </div>
      </div>
    );
  }

  if (!detailData) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
        <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <i className="fas fa-digital-tachograph text-blue-600"></i>
          ASN Deep Dive
        </h3>
        <p className="text-sm text-slate-500">Select an ASN from the map or search to view its detailed information.</p>
      </div>
    );
  }
  
  const { asn, announcedPrefixes, keyPeers, recentBGPActivity, connectivityScore, securityPostureScore, lastUpdated, isGeminiAnalyzing, geminiAnalysis } = detailData;

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-3">
        <h3 className="text-lg font-semibold flex items-center gap-2 mb-2 sm:mb-0">
          <i className="fas fa-digital-tachograph text-blue-600"></i>
          ASN Deep Dive: <span className="truncate max-w-[150px] sm:max-w-xs">{panelTitle}</span>
        </h3>
         <button
            onClick={() => onAnalyzeWithGemini(asn.id, detailData)}
            disabled={isGeminiAnalyzing}
            className="text-xs bg-indigo-500 text-white hover:bg-indigo-600 disabled:opacity-60 disabled:cursor-not-allowed px-3 py-1.5 rounded-md flex items-center gap-1.5 transition-colors duration-150 shadow-sm self-start sm:self-center"
            aria-label={`Analyze ${asn.id} details with Gemini`}
          >
            <i className={`fas ${isGeminiAnalyzing ? 'fa-spinner fa-spin' : 'fa-wand-magic-sparkles'}`}></i>
            {isGeminiAnalyzing ? 'Analyzing...' : 'Ask Gemini'}
          </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3 text-xs">
        <div className="bg-blue-50 p-2 rounded-md">
          <span className="font-semibold text-blue-700">Connectivity Score:</span> {connectivityScore}/100
          <div className="w-full bg-blue-200 rounded-full h-1.5 mt-1"><div className="bg-blue-500 h-1.5 rounded-full" style={{ width: `${connectivityScore}%` }}></div></div>
        </div>
        <div className="bg-red-50 p-2 rounded-md">
          <span className="font-semibold text-red-700">Security Posture:</span> {securityPostureScore}/100
           <div className="w-full bg-red-200 rounded-full h-1.5 mt-1"><div className="bg-red-500 h-1.5 rounded-full" style={{ width: `${securityPostureScore}%` }}></div></div>
        </div>
      </div>
       {geminiAnalysis && (
          <div className="mb-3 mt-1 p-2.5 bg-indigo-50 border border-indigo-200 rounded-md shadow-sm">
            <h5 className="text-xs font-semibold text-indigo-700 mb-1 flex items-center">
              <i className="fas fa-microchip mr-1.5 text-indigo-500"></i>Gemini Analysis
            </h5>
            <p className="text-xs text-indigo-800 whitespace-pre-wrap">{geminiAnalysis}</p>
          </div>
        )}

      <div className="analysis-panel max-h-[calc(100vh-450px)] sm:max-h-[300px] md:max-h-[350px] lg:max-h-[400px] xl:max-h-[300px] pr-1">
        <Section title="Announced Prefixes" icon="fas fa-list-ol" defaultOpen={true}>
          {announcedPrefixes.length > 0 ? (
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-100">
                <tr>
                  <th className="px-2 py-1 text-left font-medium text-slate-600">Prefix</th>
                  <th className="px-2 py-1 text-left font-medium text-slate-600">Description</th>
                  <th className="px-2 py-1 text-left font-medium text-slate-600">RPKI</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-100">
                {announcedPrefixes.map(p => {
                  const rpki = getRPKIStatusVisuals(p.rpkiStatus);
                  return (
                    <tr key={p.prefix}>
                      <td className="px-2 py-1 whitespace-nowrap font-mono">{p.prefix}</td>
                      <td className="px-2 py-1">{p.description}</td>
                      <td className="px-2 py-1 whitespace-nowrap">
                        <span className={`${rpki.color} flex items-center gap-1`}><i className={rpki.icon}></i> {rpki.text}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : <p className="text-slate-500 italic">No specific prefix announcements found.</p>}
        </Section>

        <Section title="Key Relationships" icon="fas fa-users" defaultOpen={true}>
          {keyPeers.length > 0 ? keyPeers.map(p => (
            <div key={p.asnId} className="p-2 border-b border-slate-100 last:border-b-0">
              <p className="font-semibold text-slate-800">
                {COUNTRY_FLAGS[p.country] || '🌐'} {p.asnId} <span className="font-normal text-slate-600">({p.org})</span>
              </p>
              <p><span className="font-medium text-slate-500">Type:</span> {p.relationshipType}</p>
              {p.bandwidth && <p><span className="font-medium text-slate-500">Bandwidth:</span> {p.bandwidth}</p>}
              {p.connectionSince && <p><span className="font-medium text-slate-500">Since:</span> {new Date(p.connectionSince).toLocaleDateString()}</p>}
            </div>
          )) : <p className="text-slate-500 italic">No specific key relationships found.</p>}
        </Section>

        <Section title="Recent BGP Activity" icon="fas fa-history">
          {recentBGPActivity.length > 0 ? recentBGPActivity.map((a, idx) => (
            <div key={idx} className="p-2 border-b border-slate-100 last:border-b-0">
              <p className="font-semibold text-slate-800 capitalize">{a.type.replace(/_/g, ' ')} <span className="font-normal text-slate-500">({new Date(a.timestamp).toLocaleString()})</span></p>
              <p>{a.summary}</p>
              {a.relatedPrefix && <p className="text-blue-600">Prefix: {a.relatedPrefix}</p>}
            </div>
          )) : <p className="text-slate-500 italic">No recent BGP activity specific to this ASN found.</p>}
        </Section>
      </div>
      <p className="text-right text-xs text-slate-400 mt-2">Last simulated update: {new Date(lastUpdated).toLocaleString()}</p>
    </div>
  );
};

export default ASNDetailView;
