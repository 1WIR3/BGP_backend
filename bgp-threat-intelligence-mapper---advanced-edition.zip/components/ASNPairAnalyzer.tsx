
import React from 'react';
import { ASNNode, ResolvedBGPLink, ASPathData, ASPathSegment } from '../types';
import { COUNTRY_FLAGS } from '../constants';
import { LINK_TYPE_ICONS, getLinkTypeStyles } from './RelationshipAnalysis'; // Re-use from RelationshipAnalysis

interface ASNDetailCardProps {
  node: ASNNode;
  title: string;
}

const ASNDetailCard: React.FC<ASNDetailCardProps> = ({ node, title }) => (
  <div className="p-3 bg-slate-100 rounded-lg shadow">
    <h4 className="text-sm font-semibold text-slate-700 mb-1">{title}</h4>
    <p className="text-sm">
      <span className="font-mono text-blue-600">{COUNTRY_FLAGS[node.country] || '🌐'} {node.id}</span> - {node.name}
    </p>
    <p className="text-xs text-slate-600">{node.org}</p>
    <p className={`text-xs capitalize font-medium ${
      node.threat === 'critical' || node.threat === 'high' ? 'text-red-600' :
      node.threat === 'medium' ? 'text-orange-500' : 'text-green-600'
    }`}>
      Threat: {node.threat}
    </p>
  </div>
);

interface ASPathSegmentPillProps {
  segment: ASPathSegment;
  isFirst: boolean;
  isLast: boolean;
}

// Simplified version from ASPathAnalysis for local use
const ASPathSegmentDisplay: React.FC<ASPathSegmentPillProps> = ({ segment, isFirst, isLast }) => {
  let bgColor = 'bg-slate-200';
  let textColor = 'text-slate-700';

  if (segment.isSuspectedHijacker) {
    bgColor = 'bg-red-500';
    textColor = 'text-white';
  } else if (segment.isRpkiValid === false) {
    bgColor = 'bg-orange-400';
    textColor = 'text-white';
  } else if (segment.isRpkiValid === true) {
    bgColor = 'bg-green-500';
    textColor = 'text-white';
  }
  
  return (
    <div className={`flex items-center px-2 py-1 rounded-full text-xs font-medium ${bgColor} ${textColor} shadow-sm whitespace-nowrap`}>
      {COUNTRY_FLAGS[segment.country] || '🌐'}
      <span className="ml-1.5">{segment.asn}</span>
      <span className="ml-1 text-xs opacity-80 truncate hidden sm:inline">({segment.org.substring(0,15)}{segment.org.length > 15 ? '...' : ''})</span>
    </div>
  );
};


interface ASNPairAnalyzerProps {
  sourceASNInput: string;
  destinationASNInput: string;
  onSetSourceASNInput: (value: string) => void;
  onSetDestinationASNInput: (value: string) => void;
  onAnalyzePair: () => void;
  analysisResult: {
    sourceNode?: ASNNode;
    destinationNode?: ASNNode;
    directLinks?: ResolvedBGPLink[];
    paths?: ASPathData[];
    error?: string;
  } | null;
  isLoading: boolean;
}

const ASNPairAnalyzer: React.FC<ASNPairAnalyzerProps> = ({
  sourceASNInput,
  destinationASNInput,
  onSetSourceASNInput,
  onSetDestinationASNInput,
  onAnalyzePair,
  analysisResult,
  isLoading,
}) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
      <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
        <i className="fas fa-search-location text-teal-600"></i>
        ASN Pair Relationship Analyzer
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
        <input
          type="text"
          value={sourceASNInput}
          onChange={(e) => onSetSourceASNInput(e.target.value.toUpperCase())}
          placeholder="Source ASN (e.g., AS13335)"
          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent shadow-sm text-sm"
          aria-label="Source ASN"
        />
        <input
          type="text"
          value={destinationASNInput}
          onChange={(e) => onSetDestinationASNInput(e.target.value.toUpperCase())}
          placeholder="Destination ASN (e.g., AS15169)"
          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent shadow-sm text-sm"
          aria-label="Destination ASN"
        />
      </div>
      <button
        onClick={onAnalyzePair}
        disabled={isLoading || !sourceASNInput || !destinationASNInput}
        className="w-full px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors shadow-sm active:bg-teal-800 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        aria-label="Analyze ASN Pair"
      >
        {isLoading ? (
          <><i className="fas fa-spinner fa-spin"></i> Analyzing...</>
        ) : (
          <><i className="fas fa-play"></i> Analyze Pair</>
        )}
      </button>

      {analysisResult && (
        <div className="mt-4 pt-4 border-t border-gray-200">
          {analysisResult.error && (
            <p className="text-red-600 bg-red-50 p-3 rounded-md text-sm"><i className="fas fa-exclamation-triangle mr-2"></i>{analysisResult.error}</p>
          )}

          {analysisResult.sourceNode && analysisResult.destinationNode && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <ASNDetailCard node={analysisResult.sourceNode} title="Source ASN" />
              <ASNDetailCard node={analysisResult.destinationNode} title="Destination ASN" />
            </div>
          )}

          {analysisResult.directLinks && analysisResult.directLinks.length > 0 && (
            <div className="mb-4">
              <h4 className="text-md font-semibold text-slate-800 mb-2">Direct Connection(s):</h4>
              <div className="space-y-2">
                {analysisResult.directLinks.map((link, idx) => {
                  const partnerNode = link.source.id === analysisResult.sourceNode?.id ? link.target : link.source;
                  const styles = getLinkTypeStyles(link.type);
                  const linkKey = link.id || `${link.source.id}-${link.target.id}-${link.type}-${idx}`;
                  return (
                    <div key={linkKey} className={`p-3 rounded-md border-l-4 ${styles.borderColor} ${styles.bgColor} transition-shadow hover:shadow-sm`}>
                      <div className="flex items-center justify-between mb-1">
                        <h5 className={`font-semibold text-sm flex items-center gap-2 ${styles.color}`}>
                          <i className={`${LINK_TYPE_ICONS[link.type]}`}></i>
                          <span>
                            {styles.name} with {COUNTRY_FLAGS[partnerNode.country] || '🌐'} {partnerNode.id}
                            <span className="font-normal text-gray-600 hidden sm:inline"> ({partnerNode.name})</span>
                          </span>
                        </h5>
                        {link.suspicious && <span className="text-xs bg-red-500 text-white px-2 py-0.5 rounded-full font-bold">SUSPICIOUS</span>}
                      </div>
                      <div className="text-xs text-gray-700 space-y-0.5 pl-6">
                        {link.bandwidth && <p><span className="font-medium">Bandwidth:</span> {link.bandwidth}</p>}
                        {link.established && <p><span className="font-medium">Established:</span> {new Date(link.established).toLocaleDateString()}</p>}
                         {link.geopolitical && <p className="text-red-600 font-medium"><i className="fas fa-flag mr-1"></i>Geopolitical Interest</p>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {analysisResult.paths && analysisResult.paths.length > 0 && (
            <div>
              <h4 className="text-md font-semibold text-slate-800 mb-2">{analysisResult.directLinks && analysisResult.directLinks.length > 0 ? "Additional 2-Hop Paths:" : "Found 2-Hop Path(s):"}</h4>
              <div className="space-y-3">
                {analysisResult.paths.map((pathInfo) => (
                  <div key={pathInfo.id} className="p-3 bg-slate-50 rounded-lg shadow-sm">
                    <div className="flex items-center space-x-1 overflow-x-auto pb-1">
                      {pathInfo.path.map((segment, index) => (
                        <React.Fragment key={`${segment.asn}-${index}`}>
                          <ASPathSegmentDisplay segment={segment} isFirst={index === 0} isLast={index === pathInfo.path.length -1} />
                          {index < pathInfo.path.length - 1 && (
                            <i className="fas fa-arrow-right text-slate-400 text-xs mx-1"></i>
                          )}
                        </React.Fragment>
                      ))}
                    </div>
                     { (pathInfo.isPotentiallyHijacked || pathInfo.isRouteLeak) && 
                        <p className="text-xs mt-1.5">
                            {pathInfo.isPotentiallyHijacked && <span className="font-bold text-red-600">[HIJACK ALERT] </span>}
                            {pathInfo.isRouteLeak && <span className="font-bold text-orange-600">[LEAK DETECTED]</span>}
                        </p>
                    }
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {!(analysisResult.directLinks && analysisResult.directLinks.length > 0) && !(analysisResult.paths && analysisResult.paths.length > 0) && analysisResult.sourceNode && analysisResult.destinationNode && !analysisResult.error && (
            <p className="text-slate-600 bg-slate-50 p-3 rounded-md text-sm"><i className="fas fa-info-circle mr-2"></i>No direct or simple 2-hop relationship found between {analysisResult.sourceNode.id} and {analysisResult.destinationNode.id}.</p>
          )}

        </div>
      )}
    </div>
  );
};

export default ASNPairAnalyzer;
