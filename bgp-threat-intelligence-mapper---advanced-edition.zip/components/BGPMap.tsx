
import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as d3 from 'd3';
import { ASNNode, ResolvedBGPLink, TooltipData } from '../types'; // BGPLink changed to ResolvedBGPLink for props
import { THREAT_LEVELS, COUNTRY_FLAGS, LINK_LEGEND_ITEMS } from '../constants';

interface BGPMapProps {
  nodesData: ASNNode[];
  linksData: ResolvedBGPLink[]; // Changed from BGPLink[]
  mapStatusText: string;
  onNodeClick: (node: ASNNode) => void;
  setTooltipData: React.Dispatch<React.SetStateAction<TooltipData>>;
}

const BGPMap: React.FC<BGPMapProps> = ({ nodesData, linksData, mapStatusText, onNodeClick, setTooltipData }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  
  const simulationRef = useRef<d3.Simulation<ASNNode, ResolvedBGPLink> | null>(null);
  const zoomRef = useRef<d3.ZoomBehavior<SVGSVGElement, unknown> | null>(null);
  const gRef = useRef<SVGGElement | null>(null);

  // Store selections for access in event handlers
  const nodeElementsRef = useRef<d3.Selection<SVGGElement, ASNNode, SVGGElement, unknown> | null>(null);
  const linkElementsRef = useRef<d3.Selection<SVGPathElement, ResolvedBGPLink, SVGGElement, unknown> | null>(null);


  const handleResize = useCallback(() => {
    if (svgRef.current?.parentElement) {
      const parentWidth = svgRef.current.parentElement.clientWidth;
      const parentHeight = svgRef.current.parentElement.clientHeight > 0 ? svgRef.current.parentElement.clientHeight : 600;

      setDimensions({ width: parentWidth, height: parentHeight });
      if (simulationRef.current) {
        simulationRef.current.force("center", d3.forceCenter(parentWidth / 2, parentHeight / 2));
        simulationRef.current.alpha(0.3).restart();
      }
    }
  }, []);

  useEffect(() => {
    handleResize(); 
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [handleResize]);


  useEffect(() => {
    if (!svgRef.current || !nodesData || !linksData || dimensions.width === 0 || dimensions.height === 0) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove(); 

    svg.attr("viewBox", `0 0 ${dimensions.width} ${dimensions.height}`)
       .style("background", "linear-gradient(135deg, #f8fafc 0%, #e2e8f0 50%, #cbd5e1 100%)");

    const g = svg.append("g");
    gRef.current = g.node();

    if (!simulationRef.current) {
        simulationRef.current = d3.forceSimulation<ASNNode, ResolvedBGPLink>()
            .force("link", d3.forceLink<ASNNode, ResolvedBGPLink>().id(d => d.id).distance(d => (d.type === 'hijack' ? 150 : (d.type === 'leak' ? 120 : 100))))
            .force("charge", d3.forceManyBody<ASNNode>().strength(d => d.threat === 'critical' ? -600 : (d.threat === 'high' ? -450 : -300)))
            .force("center", d3.forceCenter(dimensions.width / 2, dimensions.height / 2))
            .force("collision", d3.forceCollide<ASNNode>().radius(d => (getNodeRadius(d) * 1.1))) 
            .force("x", d3.forceX(dimensions.width / 2).strength(0.05))
            .force("y", d3.forceY(dimensions.height / 2).strength(0.05));
    }
    
    const simulation = simulationRef.current;
    
    linkElementsRef.current = g.append("g")
      .attr("class", "links")
      .selectAll<SVGPathElement, ResolvedBGPLink>("path") // Explicitly type selected elements
      .data(linksData, (d: ResolvedBGPLink) => `${d.source.id}-${d.target.id}-${d.type}`)
      .join("path")
      .attr("class", (d: ResolvedBGPLink) => {
          let classes = `bgp-link link-type-${d.type}`;
          if (d.suspicious) classes += ' suspicious';
          return classes;
      })
      .attr("id", (d: ResolvedBGPLink, i) => `link-${i}-${d.source.id}-${d.target.id}`);


    nodeElementsRef.current = g.append("g")
      .attr("class", "nodes")
      .selectAll<SVGGElement, ASNNode>("g") // Explicitly type selected elements
      .data(nodesData, (d: ASNNode) => d.id)
      .join("g")
      .attr("class", "node-group")
      .call(drag(simulation) as any) 
      .on("click", (event, d_node: ASNNode) => {
        event.stopPropagation();
        onNodeClick(d_node);
      })
      .on("mouseover", (event, d_node: ASNNode) => {
        d3.select(event.currentTarget).select("circle").transition().duration(150).attr("r", getNodeRadius(d_node) * 1.2);
        setTooltipData({ visible: true, content: '', x: event.pageX + 15, y: event.pageY - 10, asn: d_node });

        if (nodeElementsRef.current && linkElementsRef.current) {
            const neighborIds = new Set<string>();
            linksData.forEach(link => {
                if (link.source.id === d_node.id) neighborIds.add(link.target.id);
                if (link.target.id === d_node.id) neighborIds.add(link.source.id);
            });

            nodeElementsRef.current.style('opacity', n => (n.id === d_node.id || neighborIds.has(n.id)) ? 1 : 0.2);
            linkElementsRef.current.style('opacity', l => (l.source.id === d_node.id || l.target.id === d_node.id) ? 1 : 0.1);
        }
      })
      .on("mousemove", (event) => {
         setTooltipData(prev => ({ ...prev, x: event.pageX + 15, y: event.pageY - 10 }));
      })
      .on("mouseout", (event, d_node: ASNNode) => {
        d3.select(event.currentTarget).select("circle").transition().duration(150).attr("r", getNodeRadius(d_node));
        setTooltipData({ visible: false, content: '', x: 0, y: 0, asn: undefined });

        if (nodeElementsRef.current && linkElementsRef.current) {
            nodeElementsRef.current.style('opacity', 1);
            linkElementsRef.current.style('opacity', null); // Reverts to CSS defined opacity
        }
      });

    nodeElementsRef.current.append("circle")
      .attr("r", d_node => getNodeRadius(d_node))
      .attr("class", d_node => `node-circle threat-${d_node.threat}`)
      .style("cursor", "pointer");

    nodeElementsRef.current.append("text")
      .text(d_node => COUNTRY_FLAGS[d_node.country] || '🌐')
      .attr("class", "country-flag")
      .attr("text-anchor", "middle")
      .attr("dy", (d_node: ASNNode) => -(getNodeRadius(d_node) + 5)) 
      .style("font-size", (d_node: ASNNode) => `${Math.max(10, getNodeRadius(d_node) * 0.6)}px`);


    nodeElementsRef.current.append("text")
      .text(d_node => d_node.id)
      .attr("class", "node-label")
      .attr("text-anchor", "middle")
      .attr("dy", "0.35em");

    simulation.nodes(nodesData).on("tick", () => {
      if (linkElementsRef.current && nodeElementsRef.current) {
        linkElementsRef.current
          .attr("d", (d_link: ResolvedBGPLink) => {
              return `M${d_link.source.x},${d_link.source.y} L${d_link.target.x},${d_link.target.y}`;
          });
        nodeElementsRef.current.attr("transform", d_node => `translate(${d_node.x},${d_node.y})`);
      }
    });

    (simulation.force("link") as d3.ForceLink<ASNNode, ResolvedBGPLink> | undefined)?.links(linksData);
    simulation.alpha(1).restart();

    if (!zoomRef.current) {
        zoomRef.current = d3.zoom<SVGSVGElement, unknown>()
            .scaleExtent([0.1, 8])
            .on("zoom", (event) => {
                if (gRef.current) {
                    d3.select(gRef.current).attr("transform", event.transform);
                }
            });
    }
    if (zoomRef.current) {
      svg.call(zoomRef.current);
    }
    
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodesData, linksData, dimensions, onNodeClick, setTooltipData]); 


  const getNodeRadius = (d_node: ASNNode): number => {
    if (d_node.threat === 'critical') return 28;
    if (d_node.threat === 'high') return 22;
    if (d_node.threat === 'medium') return 18;
    return 15;
  };

  const drag = (simulation: d3.Simulation<ASNNode, ResolvedBGPLink>) => {
    function dragstarted(event: d3.D3DragEvent<SVGGElement, ASNNode, ASNNode>, d_node: ASNNode) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      d_node.fx = d_node.x;
      d_node.fy = d_node.y;
    }
    function dragged(event: d3.D3DragEvent<SVGGElement, ASNNode, ASNNode>, d_node: ASNNode) {
      d_node.fx = event.x;
      d_node.fy = event.y;
    }
    function dragended(event: d3.D3DragEvent<SVGGElement, ASNNode, ASNNode>, d_node: ASNNode) {
      if (!event.active) simulation.alphaTarget(0);
      d_node.fx = null;
      d_node.fy = null;
    }
    return d3.drag<SVGGElement, ASNNode>()
      .on("start", dragstarted)
      .on("drag", dragged)
      .on("end", dragended);
  };

  const handleZoomIn = () => {
    if (svgRef.current && zoomRef.current) {
      d3.select(svgRef.current).transition().duration(250).call(zoomRef.current.scaleBy, 1.2);
    }
  };

  const handleZoomOut = () => {
     if (svgRef.current && zoomRef.current) {
      d3.select(svgRef.current).transition().duration(250).call(zoomRef.current.scaleBy, 0.8);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <i className="fas fa-project-diagram text-blue-600"></i>
          BGP Relationship Map
          <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">{mapStatusText}</span>
        </h3>
        <div className="hidden md:flex items-center gap-4 text-sm">
          {THREAT_LEVELS.slice(0,4).map(item => ( 
             <div key={item.level} className="flex items-center">
                <div className={`threat-indicator w-2.5 h-2.5 rounded-full mr-1.5 ${item.colorClass}`}></div>
                <span className="text-gray-600">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="flex-grow border border-gray-200 rounded relative min-h-[400px]">
        <svg ref={svgRef} id="bgp-map-svg" width="100%" height="100%"></svg> {/* Added id here */}
        <div className="absolute top-2 left-2 bg-white/90 p-2 rounded shadow-md text-xs space-y-0.5">
            {LINK_LEGEND_ITEMS.map(item => (
                <div key={item.label}><span className={`${item.colorClass} font-mono`}>{item.lineStyle}</span> {item.label}</div>
            ))}
        </div>
        <div className="absolute top-2 right-2 space-y-1">
          <button onClick={handleZoomIn} className="block w-8 h-8 bg-white shadow rounded text-center hover:bg-gray-100 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500" aria-label="Zoom In">
            <i className="fas fa-plus"></i>
          </button>
          <button onClick={handleZoomOut} className="block w-8 h-8 bg-white shadow rounded text-center hover:bg-gray-100 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500" aria-label="Zoom Out">
            <i className="fas fa-minus"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default BGPMap;
