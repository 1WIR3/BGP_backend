
import React from 'react';
import { TooltipData, ASNNode } from '../types';
import { COUNTRY_FLAGS } from '../constants';

interface TooltipProps {
  tooltipData: TooltipData;
}

const Tooltip: React.FC<TooltipProps> = ({ tooltipData }) => {
  if (!tooltipData.visible || !tooltipData.asn) {
    return null;
  }

  const asn = tooltipData.asn;

  return (
    <div
      className="graph-tooltip"
      style={{
        left: `${tooltipData.x}px`,
        top: `${tooltipData.y}px`,
        opacity: tooltipData.visible ? 1 : 0,
      }}
    >
      <div className="font-bold text-indigo-300 text-sm mb-1">
        {COUNTRY_FLAGS[asn.country] || '🌐'} {asn.id} - {asn.name}
      </div>
      <div className="text-xs">
        <p><span className="font-semibold text-indigo-400">Org:</span> {asn.org}</p>
        <p><span className="font-semibold text-indigo-400">Threat:</span> <span className={`capitalize text-${asn.threat === 'critical' || asn.threat === 'high' ? 'red-400' : asn.threat === 'medium' ? 'orange-400' : 'green-400'}`}>{asn.threat}</span></p>
        <p><span className="font-semibold text-indigo-400">Tier:</span> {asn.tier}</p>
        <p><span className="font-semibold text-indigo-400">Customers:</span> {asn.customers.toLocaleString()}</p>
        {tooltipData.content && <p className="mt-1 pt-1 border-t border-indigo-700">{tooltipData.content}</p>}
      </div>
    </div>
  );
};

export default Tooltip;