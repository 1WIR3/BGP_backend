
import React from 'react';
import { ResolvedBGPLink, ASNNode, BGPLink } from '../types';
import { COUNTRY_FLAGS } from '../constants';

interface RelationshipAnalysisProps {
  selectedASNInfo?: Pick<ASNNode, 'id' | 'name' | 'country' | 'org'> | null;
  allLinks: ResolvedBGPLink[];
}

export const LINK_TYPE_ICONS: { [key in BGPLink['type']]: string } = {
  transit: 'fas fa-exchange-alt',
  peer: 'fas fa-handshake',
  leak: 'fas fa-tint-slash',
  hijack: 'fas fa-skull-crossbones',
  geopolitical: 'fas fa-flag',
  unknown: 'fas fa-question-circle',
};

export const getLinkTypeStyles = (type: BGPLink['type']) => {
  switch (type) {
    case 'hijack': return { name: 'Hijack', color: 'text-red-700', bgColor: 'bg-red-50 hover:bg-red-100/80', borderColor: 'border-red-600' };
    case 'leak': return { name: 'Leak', color: 'text-amber-700', bgColor: 'bg-amber-50 hover:bg-amber-100/80', borderColor: 'border-amber-500' };
    case 'geopolitical': return { name: 'Geopolitical', color: 'text-red-600', bgColor: 'bg-red-50 hover:bg-red-100/80', borderColor: 'border-red-500' };
    case 'transit': return { name: 'Transit', color: 'text-purple-700', bgColor: 'bg-purple-50 hover:bg-purple-100/80', borderColor: 'border-purple-500' };
    case 'peer': return { name: 'Peering', color: 'text-blue-700', bgColor: 'bg-blue-50 hover:bg-blue-100/80', borderColor: 'border-blue-500' };
    default: return { name: 'Unknown', color: 'text-gray-700', bgColor: 'bg-gray-50 hover:bg-gray-100/80', borderColor: 'border-gray-400' };
  }
};


const RelationshipAnalysis: React.FC<RelationshipAnalysisProps> = ({ selectedASNInfo, allLinks }) => {
  if (!selectedASNInfo) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
        <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <i className="fas fa-link text-sky-600"></i>
          BGP Relationships
        </h3>
        <p className="text-sm text-gray-500">Select an ASN from the map to view its direct relationships.</p>
      </div>
    );
  }

  const relevantLinks = allLinks.filter(
    link => link.source.id === selectedASNInfo.id || link.target.id === selectedASNInfo.id
  );

  const panelTitle = (
    <>
      {COUNTRY_FLAGS[selectedASNInfo.country] || '🌐'} {selectedASNInfo.id}
      <span className="font-normal text-gray-500 text-base hidden sm:inline"> ({selectedASNInfo.org})</span>
    </>
  );

  if (relevantLinks.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
        <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <i className="fas fa-link text-sky-600"></i>
          Relationships: <span className="truncate max-w-[150px] sm:max-w-[180px] md:max-w-xs">{panelTitle}</span>
        </h3>
        <p className="text-sm text-gray-500">No direct BGP relationships found for {selectedASNInfo.id} in the current view.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
      <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
        <i className="fas fa-link text-sky-600"></i>
        Relationships: <span className="truncate max-w-[150px] sm:max-w-[180px] md:max-w-xs">{panelTitle}</span>
      </h3>
      <div className="analysis-panel max-h-96 space-y-2 pr-1">
        {relevantLinks.map((link, idx) => {
          const partnerNode = link.source.id === selectedASNInfo.id ? link.target : link.source;
          const styles = getLinkTypeStyles(link.type);
          const linkKey = link.id || `${link.source.id}-${link.target.id}-${link.type}-${idx}`;

          return (
            <div 
              key={linkKey}
              className={`p-3 rounded-md border-l-4 ${styles.borderColor} ${styles.bgColor} transition-shadow hover:shadow-md`}
              role="listitem"
              aria-label={`Relationship type ${link.type} with ${partnerNode.id} ${partnerNode.name}`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <h4 className={`font-semibold text-sm flex items-center gap-2 ${styles.color}`}>
                  <i className={`${LINK_TYPE_ICONS[link.type]}`}></i>
                  <span>
                    {styles.name} with {COUNTRY_FLAGS[partnerNode.country] || '🌐'} {partnerNode.id} 
                    <span className="font-normal text-gray-600 hidden sm:inline"> ({partnerNode.name})</span>
                  </span>
                </h4>
                {link.suspicious && (
                  <span className="text-xs bg-red-500 text-white px-2 py-0.5 rounded-full font-bold shadow-sm">SUSPICIOUS</span>
                )}
              </div>
              <div className="text-xs text-gray-700 space-y-0.5 pl-6">
                {link.bandwidth && <p><span className="font-medium">Bandwidth:</span> {link.bandwidth}</p>}
                {link.established && <p><span className="font-medium">Established:</span> {new Date(link.established).toLocaleDateString()}</p>}
                {link.geopolitical && <p className="text-red-700 font-medium"><i className="fas fa-exclamation-circle mr-1"></i>Geopolitical Interest</p>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RelationshipAnalysis;
