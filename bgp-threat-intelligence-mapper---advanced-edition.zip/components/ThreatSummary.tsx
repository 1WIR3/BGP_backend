
import React from 'react';
import { ThreatSummaryData, ASNNode } from '../types';
import { COUNTRY_FLAGS } from '../constants';

interface ThreatSummaryProps {
  threatData: ThreatSummaryData[];
  onAnalyzeWithGemini: (threatId: string) => void;
  selectedASNInfo?: Pick<ASNNode, 'id' | 'name' | 'country' | 'org'> | null;
}

const ThreatSummary: React.FC<ThreatSummaryProps> = ({ threatData, onAnalyzeWithGemini, selectedASNInfo }) => {
  const getScoreColor = (level: ASNNode['threat']): string => {
    switch (level) {
      case 'critical': return 'bg-red-700';
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-orange-500';
      case 'low': return 'bg-yellow-400';
      case 'clean': return 'bg-green-500';
      default: return 'bg-gray-400';
    }
  };
  
  const getBorderColor = (level: ASNNode['threat']): string => {
    switch (level) {
      case 'critical': return 'border-red-700';
      case 'high': return 'border-red-500';
      case 'medium': return 'border-orange-500';
      case 'low': return 'border-yellow-400';
      case 'clean': return 'border-green-500';
      default: return 'border-gray-400';
    }
  }

  const title = selectedASNInfo 
    ? (
        <>
          {COUNTRY_FLAGS[selectedASNInfo.country] || '🌐'} {selectedASNInfo.id} 
          <span className="font-normal text-gray-500 text-base hidden sm:inline"> ({selectedASNInfo.org})</span>
        </>
      )
    : "Overview";

  const emptyMessage = selectedASNInfo
    ? `No specific threat data for ${selectedASNInfo.id} (${selectedASNInfo.org}) or it's considered clean.`
    : "No threat data available or selected target is clean.";

  if (!threatData || threatData.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
        <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <i className="fas fa-exclamation-triangle text-orange-500"></i>
          Threat Intel: <span className="truncate max-w-[200px] sm:max-w-xs md:max-w-sm lg:max-w-md xl:max-w-xs">{title}</span>
        </h3>
        <p className="text-sm text-gray-500">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
      <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
        <i className="fas fa-exclamation-triangle text-orange-500"></i>
        Threat Intel: <span className="truncate max-w-[200px] sm:max-w-xs md:max-w-sm lg:max-w-md xl:max-w-xs">{title}</span>
      </h3>
      <div className="space-y-3 analysis-panel max-h-96">
        {threatData.map((threat) => (
          <div key={threat.id} className={`threat-feed-item p-3 rounded-md border-l-4 ${getBorderColor(threat.threatLevel)} bg-gradient-to-r ${threat.threatLevel === 'critical' || threat.threatLevel === 'high' ? 'from-red-50/50' : threat.threatLevel === 'medium' ? 'from-orange-50/50' : 'from-gray-50/50'} to-transparent`}>
            <div className="flex items-center justify-between mb-1">
              <h4 className="font-semibold text-sm text-gray-800">
                {COUNTRY_FLAGS[threat.country] || '🌐'} AS{threat.asn} - {threat.org}
              </h4>
              <span className={`intelligence-score inline-flex items-center justify-center w-7 h-7 rounded-full text-white font-bold text-xs ${getScoreColor(threat.threatLevel)}`}>
                {threat.score}
              </span>
            </div>
            <p className="text-xs text-gray-600 mb-1">{threat.description}</p>
            <div className="flex justify-between items-center mt-2">
                <p className="text-xs text-blue-600 font-medium">{threat.relatedEvents} related event(s)</p>
                <button
                    onClick={() => onAnalyzeWithGemini(threat.id)}
                    disabled={threat.isGeminiAnalyzing}
                    className="text-xs bg-indigo-100 text-indigo-700 hover:bg-indigo-200 disabled:opacity-60 disabled:cursor-not-allowed px-2 py-1 rounded-md flex items-center gap-1.5 transition-colors duration-150"
                    aria-label={`Analyze AS${threat.asn} with Gemini`}
                    aria-live="polite" // To announce changes when button text/state changes
                    aria-busy={threat.isGeminiAnalyzing}
                >
                    <i className={`fas ${threat.isGeminiAnalyzing ? 'fa-spinner fa-spin' : 'fa-wand-magic-sparkles'}`}></i>
                    {threat.isGeminiAnalyzing ? 'Analyzing...' : 'Ask Gemini'}
                </button>
            </div>

            {threat.geminiAnalysis && (
              <div className="mt-3 p-2.5 bg-indigo-50 border border-indigo-200 rounded-md shadow-sm">
                <h5 className="text-xs font-semibold text-indigo-700 mb-1 flex items-center">
                  <i className="fas fa-microchip mr-1.5 text-indigo-500"></i>Gemini Analysis
                </h5>
                <p className="text-xs text-indigo-800 whitespace-pre-wrap">{threat.geminiAnalysis}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ThreatSummary;
