import React from 'react';
import { AnalysisHistoryItem, LayoutMode } from '../types';

interface ControlPanelProps {
  targetIP: string;
  setTargetIP: (value: string) => void;
  analyzeTarget: () => void;
  analysisHistory: AnalysisHistoryItem[];
  loadHistoricalAnalysis: (id: string) => void;
  detectHijacks: boolean;
  setDetectHijacks: (value: boolean) => void;
  detectLeaks: boolean;
  setDetectLeaks: (value: boolean) => void;
  detectGeopolitical: boolean;
  setDetectGeopolitical: (value: boolean) => void;
  realTimeMonitoring: boolean;
  setRealTimeMonitoring: (value: boolean) => void;
  layoutMode: LayoutMode;
  setLayoutMode: (value: LayoutMode) => void;
  timelineValue: number;
  setTimelineValue: (value: number) => void;
  timelineDate: string;
  resetView: () => void;
  exportAnalysis: () => void;
  exportGraphImage: () => void; // New prop
  exportDataReport: () => void; // New prop
  toggleFullscreen: () => void;
  feedRIPE: boolean;
  setFeedRIPE: (value: boolean) => void;
  feedRouteViews: boolean;
  setFeedRouteViews: (value: boolean) => void;
  feedThreatIntel: boolean;
  setFeedThreatIntel: (value: boolean) => void;
  feedStatusActive: boolean;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  targetIP, setTargetIP, analyzeTarget, analysisHistory, loadHistoricalAnalysis,
  detectHijacks, setDetectHijacks, detectLeaks, setDetectLeaks,
  detectGeopolitical, setDetectGeopolitical, realTimeMonitoring, setRealTimeMonitoring,
  layoutMode, setLayoutMode, timelineValue, setTimelineValue, timelineDate,
  resetView, exportAnalysis, exportGraphImage, exportDataReport, toggleFullscreen,
  feedRIPE, setFeedRIPE, feedRouteViews, setFeedRouteViews,
  feedThreatIntel, setFeedThreatIntel, feedStatusActive
}) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6 transition-all duration-300 ease-in-out hover:shadow-2xl">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Target Analysis */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <i className="fas fa-search mr-2"></i>Target Analysis
          </label>
          <div className="space-y-2">
            <div className="flex gap-2">
              <input
                type="text"
                value={targetIP}
                onChange={(e) => setTargetIP(e.target.value)}
                placeholder="IP, ASN, or Domain"
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
                aria-label="Target IP, ASN, or Domain for analysis"
              />
              <button
                onClick={analyzeTarget}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm active:bg-blue-800"
                aria-label="Analyze Target"
              >
                <i className="fas fa-play"></i>
              </button>
            </div>
            <select 
              className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm shadow-sm focus:ring-1 focus:ring-blue-500"
              onChange={(e) => loadHistoricalAnalysis(e.target.value)}
              defaultValue=""
              aria-label="Recent Analyses History"
            >
              <option value="">Recent Analyses</option>
              {analysisHistory.map(item => (
                <option key={item.id} value={item.id}>{item.query} - {new Date(item.timestamp).toLocaleTimeString()}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Detection Engine */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <i className="fas fa-shield-alt mr-2"></i>Detection Engine
          </label>
          <div className="space-y-1">
            {[
              { label: 'BGP Hijacking', checked: detectHijacks, setter: setDetectHijacks, id: 'detectHijacks' },
              { label: 'Route Leaks', checked: detectLeaks, setter: setDetectLeaks, id: 'detectLeaks' },
              { label: 'Geopolitical Routing', checked: detectGeopolitical, setter: setDetectGeopolitical, id: 'detectGeopolitical' },
              { label: 'Live Monitoring', checked: realTimeMonitoring, setter: setRealTimeMonitoring, id: 'realTimeMonitoring' },
            ].map(item => (
              <label key={item.label} htmlFor={item.id} className="flex items-center cursor-pointer">
                <input type="checkbox" id={item.id} checked={item.checked} onChange={(e) => item.setter(e.target.checked)} className="mr-2 h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"/>
                <span className="text-sm text-gray-600">{item.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Visualization & Timeline */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <i className="fas fa-eye mr-2"></i>Visualization & Exports
          </label>
          <div className="space-y-2">
            <select 
              value={layoutMode} 
              onChange={(e) => setLayoutMode(e.target.value as LayoutMode)} 
              className="w-full px-3 py-1.5 border border-gray-300 rounded-lg text-sm shadow-sm focus:ring-1 focus:ring-blue-500"
              aria-label="Select Layout Mode"
            >
              <option value={LayoutMode.Force}>Force Layout</option>
              <option value={LayoutMode.Radial}>Radial Layout</option>
              <option value={LayoutMode.Hierarchical}>Hierarchical</option>
              <option value={LayoutMode.Geographical}>Geographical Map</option>
            </select>
            <div className="flex items-center gap-1">
              <label htmlFor="timelineSlider" className="sr-only">Timeline Slider</label>
              <input 
                type="range" 
                id="timelineSlider"
                min="0" max="100" 
                value={timelineValue} 
                onChange={(e) => setTimelineValue(Number(e.target.value))} 
                className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <span id="timelineDateLabel" className="text-xs text-gray-500 w-10 text-right" aria-live="polite">{timelineDate}</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-2 xl:grid-cols-3 gap-2 mt-1">
              {[
                { label: <i className="fas fa-undo"></i>, action: resetView, color: 'bg-gray-500 hover:bg-gray-600', aria: 'Reset View' },
                { label: <i className="fas fa-download"></i>, action: exportAnalysis, color: 'bg-green-600 hover:bg-green-700', aria: 'Export Analysis (JSON)' },
                { label: <i className="fas fa-image"></i>, action: exportGraphImage, color: 'bg-teal-600 hover:bg-teal-700', aria: 'Export Graph (SVG)' },
                { label: <i className="fas fa-file-alt"></i>, action: exportDataReport, color: 'bg-sky-600 hover:bg-sky-700', aria: 'Export Report (TXT)' },
                { label: <i className="fas fa-expand"></i>, action: toggleFullscreen, color: 'bg-purple-600 hover:bg-purple-700', aria: 'Toggle Fullscreen' },
              ].map(btn => (
                <button key={btn.aria} onClick={btn.action} className={`px-3 py-1.5 text-white rounded-md text-xs transition-colors shadow-sm active:opacity-80 flex items-center justify-center ${btn.color}`} aria-label={btn.aria}>
                  {btn.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        {/* Intelligence Feeds */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <i className="fas fa-rss mr-2"></i>Intelligence Feeds
          </label>
          <div className="mb-2 text-xs text-gray-600">
            Backend Status: <span className="bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-medium">Simulated</span>
          </div>
          <div className="space-y-1">
            {[
              { label: 'RIPE NCC', checked: feedRIPE, setter: setFeedRIPE, id: 'feedRIPE' },
              { label: 'RouteViews', checked: feedRouteViews, setter: setFeedRouteViews, id: 'feedRouteViews' },
              { label: 'Threat Intel', checked: feedThreatIntel, setter: setFeedThreatIntel, id: 'feedThreatIntel' },
            ].map(item => (
              <label key={item.label} htmlFor={item.id} className="flex items-center cursor-pointer">
                <input type="checkbox" id={item.id} checked={item.checked} onChange={(e) => item.setter(e.target.checked)} className="mr-2 h-4 w-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"/>
                <span className="text-sm text-gray-600">{item.label}</span>
              </label>
            ))}
            <div className="text-xs text-gray-500 mt-2">
              <span className="inline-flex items-center" aria-live="polite" aria-label={`Feed status: ${feedStatusActive ? 'Active' : 'Inactive'}`}>
                <span className={`w-2.5 h-2.5 rounded-full mr-1.5 ${feedStatusActive ? 'bg-green-500' : 'bg-red-500'}`}></span>
                {feedStatusActive ? 'Active' : 'Inactive'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ControlPanel;