
import React, { useRef, useEffect } from 'react';
import { FeedEntryMessage } from '../types';

interface LiveThreatFeedProps {
  feedMessages: FeedEntryMessage[];
  feedEventCount: number;
}

const LiveThreatFeed: React.FC<LiveThreatFeedProps> = ({ feedMessages, feedEventCount }) => {
  const feedEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    feedEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [feedMessages]);
  
  const getEntryStyle = (type: FeedEntryMessage['type']) => {
    switch(type) {
      case 'critical-alert': return 'text-red-400 border-l-red-500';
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'success': return 'text-green-400';
      case 'info':
      default: return 'text-sky-400';
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
      <h3 className="text-lg font-semibold mb-3 flex items-center justify-between">
        <span className="flex items-center gap-2">
            <i className="fas fa-broadcast-tower text-red-600"></i>
            Live Threat Feed
        </span>
        <span className="text-xs bg-red-100 text-red-800 px-2 py-1 rounded-full" aria-live="polite">{feedEventCount} events</span>
      </h3>
      <div className="live-feed h-[300px] overflow-y-auto font-mono text-xs bg-slate-800 text-sky-400 p-3 rounded-md shadow-inner" role="log" aria-live="polite" aria-atomic="false">
        {feedMessages.map((entry) => (
          <div key={entry.id} className={`feed-entry mb-1 pb-1 border-b border-slate-700/50 ${getEntryStyle(entry.type)}`}>
            <span className="feed-timestamp text-slate-500 mr-2">[{entry.timestamp}]</span>
            {entry.text}
          </div>
        ))}
        <div ref={feedEndRef} />
      </div>
    </div>
  );
};

export default LiveThreatFeed;