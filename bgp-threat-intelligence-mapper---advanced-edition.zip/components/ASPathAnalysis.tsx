
import React from 'react';
import { ASPathData, ASPathSegment, ASNNode } from '../types';
import { COUNTRY_FLAGS } from '../constants';

interface ASPathAnalysisProps {
  asPathData: ASPathData[];
  selectedASNInfo?: Pick<ASNNode, 'id' | 'name' | 'country' | 'org'> | null;
}

const ASPathSegmentPill: React.FC<{ segment: ASPathSegment, isFirst: boolean, isLast: boolean }> = ({ segment, isFirst, isLast }) => {
  let bgColor = 'bg-slate-200';
  let textColor = 'text-slate-700';

  if (segment.isSuspectedHijacker) {
    bgColor = 'bg-red-500';
    textColor = 'text-white';
  } else if (segment.isRpkiValid === false) { // Explicitly check for false, as undefined means unknown
    bgColor = 'bg-orange-400';
    textColor = 'text-white';
  } else if (segment.isRpkiValid === true) {
    bgColor = 'bg-green-500';
    textColor = 'text-white';
  }
  
  return (
    <div className={`flex items-center px-2 py-1 rounded-full text-xs font-medium ${bgColor} ${textColor} shadow-sm`}>
      {COUNTRY_FLAGS[segment.country] || '🌐'}
      <span className="ml-1.5">{segment.asn}</span>
      {!isFirst && !isLast && <span className="ml-1 text-xs opacity-75">({segment.org.substring(0,10)}...)</span>}
      {(isFirst || isLast) && <span className="ml-1 text-xs opacity-90">({segment.org})</span>}
    </div>
  );
};


const ASPathAnalysis: React.FC<ASPathAnalysisProps> = ({ asPathData, selectedASNInfo }) => {
   const title = selectedASNInfo 
    ? (
        <>
          {COUNTRY_FLAGS[selectedASNInfo.country] || '🌐'} {selectedASNInfo.id} 
          <span className="font-normal text-gray-500 text-base hidden sm:inline"> ({selectedASNInfo.org})</span>
        </>
      )
    : "Overview";
  
  const emptyMessage = selectedASNInfo
    ? `No AS path data involving ${selectedASNInfo.id} (${selectedASNInfo.org}).`
    : "No AS path data available for analysis.";

   if (!asPathData || asPathData.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
        <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <i className="fas fa-route text-blue-600"></i>
          AS Paths: <span className="truncate max-w-[200px] sm:max-w-xs md:max-w-sm lg:max-w-md xl:max-w-xs">{title}</span>
        </h3>
        <p className="text-sm text-gray-500">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
      <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
        <i className="fas fa-route text-blue-600"></i>
        AS Paths: <span className="truncate max-w-[200px] sm:max-w-xs md:max-w-sm lg:max-w-md xl:max-w-xs">{title}</span>
      </h3>
      <div className="analysis-panel max-h-96 space-y-4">
        {asPathData.map((pathInfo) => (
          <div key={pathInfo.id} className="p-3 bg-slate-50 rounded-lg shadow">
            <div className="mb-2">
              <p className="text-xs text-slate-600">
                <span className="font-semibold">Path for:</span> {pathInfo.destinationPrefix}
                {pathInfo.isPotentiallyHijacked && <span className="ml-2 text-xs font-bold text-red-600 animate-pulse">[HIJACK ALERT]</span>}
                {pathInfo.isRouteLeak && <span className="ml-2 text-xs font-bold text-orange-600 animate-pulse">[LEAK DETECTED]</span>}
              </p>
            </div>
            <div className="flex items-center space-x-1 overflow-x-auto pb-2">
              {pathInfo.path.map((segment, index) => (
                <React.Fragment key={`${segment.asn}-${index}`}>
                  <ASPathSegmentPill segment={segment} isFirst={index === 0} isLast={index === pathInfo.path.length -1} />
                  {index < pathInfo.path.length - 1 && (
                    <i className="fas fa-arrow-right text-slate-400 text-xs"></i>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ASPathAnalysis;
