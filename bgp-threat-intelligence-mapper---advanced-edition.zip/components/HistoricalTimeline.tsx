
import React from 'react';
import { HistoricalEvent, ASNNode } from '../types';
import { COUNTRY_FLAGS } from '../constants';


interface HistoricalTimelineProps {
  timelineData: HistoricalEvent[];
  selectedASNInfo?: Pick<ASNNode, 'id' | 'name' | 'country' | 'org'> | null;
}

const HistoricalTimeline: React.FC<HistoricalTimelineProps> = ({ timelineData, selectedASNInfo }) => {
  const getDotClass = (severity: HistoricalEvent['severity']) => {
    if (severity === 'critical') return 'critical';
    if (severity === 'warning') return 'warning';
    return 'default';
  };

  const title = selectedASNInfo 
    ? (
        <>
          {COUNTRY_FLAGS[selectedASNInfo.country] || '🌐'} {selectedASNInfo.id} 
          <span className="font-normal text-gray-500 text-base hidden sm:inline"> ({selectedASNInfo.org})</span>
        </>
      )
    : "Overview";
  
  const emptyMessage = selectedASNInfo
    ? `No historical events for ${selectedASNInfo.id} (${selectedASNInfo.org}) in the current view.`
    : "No historical events to display for the current selection or time frame.";


  if (!timelineData || timelineData.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
        <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <i className="fas fa-history text-purple-600"></i>
          Timeline: <span className="truncate max-w-[200px] sm:max-w-xs md:max-w-sm lg:max-w-md xl:max-w-xs">{title}</span>
        </h3>
        <p className="text-sm text-gray-500">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
      <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
        <i className="fas fa-history text-purple-600"></i>
        Timeline: <span className="truncate max-w-[200px] sm:max-w-xs md:max-w-sm lg:max-w-md xl:max-w-xs">{title}</span>
      </h3>
      <div className="analysis-panel max-h-96 pr-2">
        {timelineData.map((event) => (
          <div key={event.id} className="timeline-event relative pl-5 pb-4 border-l-2 border-slate-200 last:border-l-transparent last:pb-0">
             <div className={`timeline-event-dot ${getDotClass(event.severity)}`}></div>
            <p className="text-xs text-slate-500 mb-0.5">{event.date} - {event.time}</p>
            <p className="text-sm font-medium text-slate-700 capitalize">{event.type.replace('_', ' ')}</p>
            <p className="text-xs text-slate-600">{event.description}</p>
            {event.involvedASNs && event.involvedASNs.length > 0 && (
              <p className="text-xs text-blue-500 mt-0.5">Involved: {event.involvedASNs.join(', ')}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default HistoricalTimeline;
