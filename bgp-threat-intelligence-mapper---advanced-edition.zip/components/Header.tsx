
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="gradient-bg text-white py-8">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-2 flex items-center justify-center gap-3">
            <i className="fas fa-network-wired"></i>
            BGP Threat Intelligence Mapper
            <span className="text-sm bg-red-500 px-2 py-1 rounded">ADVANCED</span>
          </h1>
          <p className="text-lg opacity-90">Advanced BGP Analysis • Historical Tracking • Real-time Monitoring • Geopolitical Intelligence</p>
        </div>
      </div>
    </header>
  );
};

export default Header;