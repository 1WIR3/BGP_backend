
import React from 'react';
import { GeopoliticalInfo, ASNNode } from '../types';
import { COUNTRY_FLAGS, GEOPOLITICAL_RISK_COUNTRIES } from '../constants';

interface GeopoliticalAnalysisProps {
  geoData: GeopoliticalInfo[];
  selectedASNInfo?: Pick<ASNNode, 'id' | 'name' | 'country' | 'org'> | null;
}

const GeopoliticalAnalysis: React.FC<GeopoliticalAnalysisProps> = ({ geoData, selectedASNInfo }) => {
  const getRiskIndicatorClasses = (risk: GeopoliticalInfo['riskFactor']): string => {
    if (risk === 'high') return 'text-red-700 bg-red-100 border-red-500';
    if (risk === 'medium') return 'text-orange-600 bg-orange-100 border-orange-500';
    return 'text-yellow-600 bg-yellow-100 border-yellow-500'; // Low risk
  };
  
  const isHighRiskCountry = (countryCode: string) => GEOPOLITICAL_RISK_COUNTRIES.includes(countryCode);

  const title = selectedASNInfo 
    ? (
        <>
          {COUNTRY_FLAGS[selectedASNInfo.country] || '🌐'} {selectedASNInfo.id} 
          <span className="font-normal text-gray-500 text-base hidden sm:inline"> ({selectedASNInfo.org})</span>
        </>
      )
    : "Overview";
  
  const emptyMessage = selectedASNInfo
    ? `No specific geopolitical concerns identified for ${selectedASNInfo.id} (${selectedASNInfo.org}).`
    : "No specific geopolitical concerns identified for the current view.";

  if (!geoData || geoData.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
        <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
          <i className="fas fa-globe text-green-600"></i>
          Geo-Intel: <span className="truncate max-w-[200px] sm:max-w-xs md:max-w-sm lg:max-w-md xl:max-w-xs">{title}</span>
        </h3>
        <p className="text-sm text-gray-500">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 transition-all duration-300 ease-in-out hover:shadow-2xl">
      <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
        <i className="fas fa-globe text-green-600"></i>
        Geo-Intel: <span className="truncate max-w-[200px] sm:max-w-xs md:max-w-sm lg:max-w-md xl:max-w-xs">{title}</span>
      </h3>
      <div className="analysis-panel max-h-96 space-y-3">
        {geoData.map((info) => (
          <div key={info.id} className={`p-3 rounded-md border-l-4 ${getRiskIndicatorClasses(info.riskFactor)}`}>
            <div className="flex items-center justify-between mb-1">
              <h4 className="font-semibold text-sm">
                {COUNTRY_FLAGS[info.country] || '🌐'} {info.asn}
                {isHighRiskCountry(info.country) && <i className="fas fa-exclamation-triangle text-red-500 ml-2" title="High Risk Country"></i>}
              </h4>
              <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getRiskIndicatorClasses(info.riskFactor).replace(/border-\w+-500/, '') /* Use bg and text color from indicator */}`}>
                {info.riskFactor.toUpperCase()} RISK
              </span>
            </div>
            <p className="text-xs text-gray-700">{info.details}</p>
            {info.relatedLinks && info.relatedLinks.length > 0 && (
                <div className="mt-2">
                    <p className="text-xs font-semibold text-gray-600">Potentially Risky Paths:</p>
                    <ul className="list-disc list-inside space-y-1 pl-1">
                        {info.relatedLinks.map((link, idx) => (
                            <li key={idx} className="text-xs text-gray-500">
                                Path via {link.source} <i className="fas fa-long-arrow-alt-right mx-1"></i> {link.target}: <span className="italic">{link.reason}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default GeopoliticalAnalysis;
