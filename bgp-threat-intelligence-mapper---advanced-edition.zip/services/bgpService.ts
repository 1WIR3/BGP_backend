
/*
Hybrid Approach: Preparing for Real BGP Data Integration

This service module is currently in a hybrid state. It simulates interactions
with a backend BGP data provider. The functions below are designed to mirror
how a real API client would operate, but they presently return mock data.

Future Backend API Structure (Hypothetical):

This service will act as a client to a backend API. The backend will be responsible for:
- Connecting to real BGP data sources (e.g., RIPE RIS, RouteViews, BGPMON).
- Storing and processing BGP data (e.g., in PostgreSQL with TimescaleDB).
- Implementing threat detection algorithms.
- Providing data via REST and WebSocket endpoints.

Example Endpoints:
- ASN & Graph Data:
  - GET /api/v1/bgp/graph?targetASN={asn} -> Provides main graph nodes and links.
    (Simulated by `generateAdvancedBGPData`)
  - GET /api/v1/bgp/asn/{asn} -> Detailed info for a specific ASN.
    (Simulated by `fetchASNDetails`)

- AS Path Analysis:
  - GET /api/v1/bgp/paths?sourceASN={asn1}&destinationASN={asn2} -> Provides AS paths.
    (Simulated by `fetchASPathData`)

- Real-time Updates:
  - WS /api/v1/bgp/updates/stream -> WebSocket endpoint for live BGP events (hijacks, leaks, etc.).
    (Simulated by `fetchMockBGPUpdates`)

- RIPE RIS Integration (Example - Backend Responsibility):
  - The backend would query RIPE RIS (e.g., using its REST API or RIPEstat data API)
    for ASN details, prefix announcements, and routing status.
  - Endpoint example: GET /api/v1/ripe/asn/{asn}
  - Endpoint example: GET /api/v1/ripe/prefix/{prefix}

Current Implementation:
- Functions like `generateAdvancedBGPData` and `fetchASPathData` mimic calls to these
  hypothetical REST endpoints but generate data locally.
- `fetchMockBGPUpdates` simulates events that would be received over a WebSocket.
- This setup allows the frontend to be developed independently while preparing for
  seamless integration with a real backend service in the future. The comments
  indicate where and how real data calls would be made.
*/

import { 
    ASNNode, BGPLink, ASPathData, ASPathSegment, BGPUpdateEvent, ResolvedBGPLink, FeedEntryMessage,
    ASNDetailedInfo, AnnouncedPrefixInfo, KeyPeerInfo, RecentBGPActivityInfo, RPKIStatus
} from '../types';
import { INITIAL_ASN_DATA, MOCK_HISTORICAL_EVENTS } from '../constants';

const SIMULATED_API_DELAY = 300; // milliseconds

/**
 * Simulates fetching the main BGP graph data.
 * In a real system, this would call a backend API endpoint.
 * This function prepares data for the main BGP visualization.
 * Future Backend Call: GET /api/v1/bgp/graph?targetASN=[targetQuery]
 * The backend would aggregate data from sources like RIPE RIS for ASN details,
 * RouteViews for topology, and its own threat intelligence database.
 * @param targetQuery Optional ASN, IP, or domain to focus the graph.
 * @returns Promise<{ nodes: ASNNode[]; links: BGPLink[] }>
 */
export const generateAdvancedBGPData = (targetQuery?: string): Promise<{ nodes: ASNNode[]; links: BGPLink[] }> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            console.log(`Simulating API call for BGP graph data (target: ${targetQuery || 'general overview'}). Will use mock data.`);
            const allNodesClone = INITIAL_ASN_DATA.nodes.map(n => ({...n}));
            const allLinksClone = INITIAL_ASN_DATA.links.map(l => ({...l}));

            if (!targetQuery || targetQuery.trim() === "") {
                resolve({ nodes: allNodesClone, links: allLinksClone });
                return;
            }
            
            const targetLower = targetQuery.toLowerCase();
            const targetNode = allNodesClone.find(n => 
                n.id.toLowerCase() === targetLower || 
                n.name.toLowerCase().includes(targetLower) ||
                n.org.toLowerCase().includes(targetLower)
            );

            if (targetNode) {
                const connectedNodes = new Set<string>();
                connectedNodes.add(targetNode.id);
                INITIAL_ASN_DATA.links.forEach(link => {
                    const sourceId = typeof link.source === 'string' ? link.source : link.source.id;
                    const targetId = typeof link.target === 'string' ? link.target : link.target.id;
                    if (sourceId === targetNode.id) connectedNodes.add(targetId);
                    if (targetId === targetNode.id) connectedNodes.add(sourceId);
                });
                
                const filteredNodes = allNodesClone.filter(n => connectedNodes.has(n.id));
                const filteredLinks = allLinksClone.filter(l => {
                    const sourceId = typeof l.source === 'string' ? l.source : (l.source as ASNNode).id;
                    const targetId = typeof l.target === 'string' ? l.target : (l.target as ASNNode).id;
                    return connectedNodes.has(sourceId) && connectedNodes.has(targetId);
                });
                resolve({ nodes: filteredNodes, links: filteredLinks });
            } else {
                resolve({ nodes: [], links: [] });
            }
        }, SIMULATED_API_DELAY);
    });
};

const SIMULATED_PATH_DELAY = 400;

/**
 * Simulates fetching AS path data between two ASNs.
 * A real backend would use BGP data sources (like RIPE RIS looking glass or RouteViews)
 * for path discovery.
 * Future Backend Call: GET /api/v1/bgp/paths?sourceASN=[sourceASNId]&destinationASN=[destinationASNId]
 * The backend would query its data sources (e.g., RIPE RIS, RouteViews) to determine paths.
 * @param sourceASNId The source ASN ID.
 * @param destinationASNId The destination ASN ID.
 * @param allNodes Current list of all nodes (used for mock data generation).
 * @returns Promise<ASPathData[]>
 */
export const fetchASPathData = (
  sourceASNId: string,
  destinationASNId: string,
  allNodes: ASNNode[]
): Promise<ASPathData[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log(`Simulating API call for AS Path data between ${sourceASNId} and ${destinationASNId}. Will use mock data.`);
      const paths: ASPathData[] = [];
      const findNode = (asnId: string): ASNNode | undefined => allNodes.find(n => n.id === asnId) || INITIAL_ASN_DATA.nodes.find(n => n.id === asnId);
      const sourceNode = findNode(sourceASNId);
      const destinationNode = findNode(destinationASNId);

      if (!sourceNode || !destinationNode) {
        resolve([]);
        return;
      }

      const createSegment = (asnId: string, overrides?: Partial<ASPathSegment>): ASPathSegment => {
        const node = findNode(asnId);
        const defaultRpki = node ? (node.threat !== 'high' && node.threat !== 'critical') : undefined;
        return {
          asn: asnId, org: node?.org || "Unknown Org", country: node?.country || "??",
          isRpkiValid: overrides?.isRpkiValid !== undefined ? overrides.isRpkiValid : defaultRpki,
          isSuspectedHijacker: overrides?.isSuspectedHijacker !== undefined ? overrides.isSuspectedHijacker : node?.threat === 'critical',
        };
      };

      // Path 1: Simple Transit Path
      const intermediateTransitNode = findNode("AS174");
      if (intermediateTransitNode && sourceNode.id !== "AS174" && destinationNode.id !== "AS174") {
        paths.push({
          id: `path-${Date.now()}-1-${sourceNode.id}-${destinationNode.id}`, sourceAS: sourceNode.id,
          destinationPrefix: `${destinationNode.id} via AS174`, path: [createSegment(sourceNode.id), createSegment("AS174"), createSegment(destinationNode.id)],
          isPotentiallyHijacked: false, isRouteLeak: false,
        });
      }

      // Path 2: Hijack Scenario
      const hijackerNode = findNode("AS64515");
      const victimIntermediary = findNode("AS4134");
      if (hijackerNode && victimIntermediary && sourceNode.id !== hijackerNode.id && destinationNode.id !== hijackerNode.id && victimIntermediary.id !== hijackerNode.id && sourceNode.id !== victimIntermediary.id && destinationNode.id !== victimIntermediary.id) {
        paths.push({
          id: `path-${Date.now()}-2-${sourceNode.id}-${destinationNode.id}`, sourceAS: sourceNode.id,
          destinationPrefix: `${destinationNode.id} via potential hijack (AS64515)`, path: [createSegment(sourceNode.id), createSegment(hijackerNode.id, { isSuspectedHijacker: true, isRpkiValid: false }), createSegment(victimIntermediary.id), createSegment(destinationNode.id)],
          isPotentiallyHijacked: true, isRouteLeak: false,
        });
      }
      
      if (paths.length === 0 && sourceNode.id !== destinationNode.id) {
         paths.push({
            id: `path-${Date.now()}-direct-${sourceNode.id}-${destinationNode.id}`, sourceAS: sourceNode.id,
            destinationPrefix: `${destinationNode.id} (direct simulation)`, path: [createSegment(sourceNode.id), createSegment(destinationNode.id)],
            isPotentiallyHijacked: destinationNode.threat === 'critical', isRouteLeak: destinationNode.threat === 'high',
         });
      }
      resolve(paths);
    }, SIMULATED_PATH_DELAY);
  });
};


const SIMULATED_EVENT_DELAY = 600;

/**
 * Simulates a backend service that processes real-time BGP data (e.g., from RIPE RIS Live,
 * RouteViews BMP streams, or BGPMON) and pushes significant detected events to the frontend.
 * In a real system, this functionality would be replaced by a WebSocket client
 * listening to an endpoint like: WS /api/v1/bgp/updates/stream
 * The backend would handle connections to data sources and event detection logic.
 * @param allNodes Current list of all nodes in the graph.
 * @param currentLinks Current list of all resolved links in the graph.
 * @returns Promise<BGPUpdateEvent[]>
 */
export const fetchMockBGPUpdates = (
    allNodes: ASNNode[],
    currentLinks: ResolvedBGPLink[] 
): Promise<BGPUpdateEvent[]> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            console.log("Simulating fetch for BGP update events. Will use mock data generation logic.");
            const events: BGPUpdateEvent[] = [];
            const now = new Date();

            if (allNodes.length === 0) {
                resolve([]);
                return;
            }

            const createEventBase = (type: BGPUpdateEvent['type'], description: string, severity: FeedEntryMessage['type']): Omit<BGPUpdateEvent, 'id'> => ({
                timestamp: now.toISOString(),
                type,
                description,
                severity,
            });

            const numEvents = Math.floor(Math.random() * 3); 

            for (let i = 0; i < numEvents; i++) {
                const eventTypeRoll = Math.random();
                let randomNode1 = allNodes[Math.floor(Math.random() * allNodes.length)];
                let randomNode2 = allNodes[Math.floor(Math.random() * allNodes.length)];
                while (randomNode1.id === randomNode2.id && allNodes.length > 1) {
                    randomNode2 = allNodes[Math.floor(Math.random() * allNodes.length)];
                }

                if (eventTypeRoll < 0.2 && randomNode1.threat !== 'critical' && randomNode2.threat === 'critical') { 
                    const victim = randomNode1;
                    const hijacker = randomNode2;
                    const linkExists = currentLinks.some(l =>
                        (l.source.id === hijacker.id && l.target.id === victim.id && l.type === 'hijack') ||
                        (l.source.id === victim.id && l.target.id === hijacker.id && l.type === 'hijack')
                    );
                    if (!linkExists) {
                        events.push({
                            ...createEventBase('new_hijack', `BGP Hijack Alert: ${hijacker.id} (${hijacker.org}) is suspected of hijacking prefixes belonging to ${victim.id} (${victim.org}). Traffic rerouted.`, 'critical-alert'),
                            id: `evt-hijack-${now.getTime()}-${i}`,
                            sourceAS: hijacker.id,
                            targetAS: victim.id,
                            prefix: `10.${Math.floor(Math.random()*255)}.0.0/16`
                        });
                    }
                } else if (eventTypeRoll < 0.4 && randomNode1.threat !== 'high' && randomNode2.threat === 'high') { 
                    const affected = randomNode1;
                    const leaker = randomNode2;
                     const linkExists = currentLinks.some(l =>
                        (l.source.id === leaker.id && l.target.id === affected.id && l.type === 'leak') ||
                        (l.source.id === affected.id && l.target.id === leaker.id && l.type === 'leak')
                    );
                    if (!linkExists) {
                        events.push({
                            ...createEventBase('new_leak', `Route Leak Detected: ${leaker.id} (${leaker.org}) is leaking routes to ${affected.id} (${affected.org}), potentially exposing internal network structure.`, 'warning'),
                            id: `evt-leak-${now.getTime()}-${i}`,
                            sourceAS: leaker.id,
                            targetAS: affected.id,
                        });
                    }
                } else if (eventTypeRoll < 0.6) { 
                     const linkExists = currentLinks.some(l =>
                        ((l.source.id === randomNode1.id && l.target.id === randomNode2.id) ||
                         (l.source.id === randomNode2.id && l.target.id === randomNode1.id)) && l.type === 'peer'
                    );
                    if (!linkExists && randomNode1.tier < 3 && randomNode2.tier < 3) { 
                         events.push({
                            ...createEventBase('new_peering', `New Peering Established: ${randomNode1.id} (${randomNode1.org}) and ${randomNode2.id} (${randomNode2.org}) have established a new peering connection.`, 'success'),
                            id: `evt-peer-${now.getTime()}-${i}`,
                            sourceAS: randomNode1.id,
                            targetAS: randomNode2.id,
                        });
                    }
                } else if (eventTypeRoll < 0.8) { 
                    const targetNode = randomNode1;
                    const oldStatus = Math.random() < 0.5 ? 'valid' : 'invalid';
                    const newStatus = oldStatus === 'valid' ? 'invalid' : 'valid';
                    events.push({
                         ...createEventBase('rpki_status_change', `RPKI Status Change for prefix announced by ${targetNode.id} (${targetNode.org}): Changed from ${oldStatus} to ${newStatus}.`, newStatus === 'invalid' ? 'warning' : 'info'),
                        id: `evt-rpki-${now.getTime()}-${i}`,
                        relatedASNs: [targetNode.id],
                        prefix: `203.0.113.${Math.floor(Math.random()*255)}/24`,
                        newRpkiStatus: newStatus,
                        oldRpkiStatus: oldStatus
                    });
                } else { 
                    events.push({
                        ...createEventBase('general_update', `Routing update from ${randomNode1.id}: Path change detected for prefix 198.51.100.0/24. Stability nominal.`, 'info'),
                        id: `evt-gen-${now.getTime()}-${i}`,
                        relatedASNs: [randomNode1.id],
                        prefix: `198.51.100.0/24`
                    });
                }
            }
            resolve(events);
        }, SIMULATED_EVENT_DELAY);
    });
};

const SIMULATED_ASN_DETAIL_DELAY = 500;

/**
 * Simulates fetching detailed information for a specific ASN.
 * In a real system, this would call a backend API endpoint (e.g., GET /api/v1/bgp/asn/{asnId})
 * which gathers data from RIPE RIS, RouteViews, internal databases, etc.
 * @param asnId The ID of the ASN to fetch details for.
 * @param allNodes All current nodes (used to find the target ASN and its peers).
 * @param allLinks All current links (used to derive peer relationships).
 * @returns Promise<ASNDetailedInfo | null>
 */
export const fetchASNDetails = (
  asnId: string,
  allNodes: ASNNode[],
  allLinks: ResolvedBGPLink[]
): Promise<ASNDetailedInfo | null> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log(`Simulating API call for detailed ASN data for ${asnId}. Will use mock data.`);
      const targetNode = allNodes.find(n => n.id === asnId);

      if (!targetNode) {
        resolve(null);
        return;
      }

      const mockRpkiStatus = (): RPKIStatus => {
        const rand = Math.random();
        if (rand < 0.7) return 'valid';
        if (rand < 0.9) return 'invalid';
        return 'unknown';
      };

      const announcedPrefixes: AnnouncedPrefixInfo[] = [];
      for (let i = 0; i < Math.floor(Math.random() * 5) + 2; i++) {
        const ipPart1 = Math.floor(Math.random() * 255) + 1;
        const ipPart2 = Math.floor(Math.random() * 255);
        const subnet = Math.floor(Math.random() * 10) + 15; // /15 to /24
        announcedPrefixes.push({
          prefix: `${ipPart1}.${ipPart2}.${Math.floor(Math.random() * 255)}.0/${subnet}`,
          description: `Customer Routes Block ${i+1}`,
          rpkiStatus: mockRpkiStatus(),
          originAS: targetNode.id,
        });
      }
       if (targetNode.id === "AS64515") { // Hijacker example
            announcedPrefixes.push({ prefix: `1.2.3.0/24`, description: "Hijacked prefix from AS4134", rpkiStatus: 'invalid', originAS: targetNode.id});
        }
        if (targetNode.id === "AS4134") { // Victim example
             announcedPrefixes.push({ prefix: `1.2.3.0/24`, description: "Legitimate prefix", rpkiStatus: 'valid', originAS: targetNode.id});
        }


      const keyPeers: KeyPeerInfo[] = [];
      const connectedLinks = allLinks.filter(l => l.source.id === targetNode.id || l.target.id === targetNode.id);
      
      connectedLinks.slice(0, 5).forEach(link => {
        const peerNode = link.source.id === targetNode.id ? link.target : link.source;
        let relationshipType: KeyPeerInfo['relationshipType'] = 'Unknown';
        if (link.type === 'transit') {
            // Simple heuristic: if peer is Tier 1, it's likely a provider to targetNode (if targetNode is not Tier 1)
            // Or if targetNode is Tier 1, peerNode is likely a customer. This is very simplified.
            if (peerNode.tier < targetNode.tier) relationshipType = 'Transit Provider';
            else if (targetNode.tier < peerNode.tier) relationshipType = 'Customer';
            else relationshipType = 'Transit Provider'; // Could be either
        } else if (link.type === 'peer') {
            relationshipType = 'Public Peer'; // Assume public for simplicity
        } else if (link.type === 'hijack' || link.type === 'leak') {
            relationshipType = 'Unknown'; // Relationship is troubled
        }
        
        keyPeers.push({
          asnId: peerNode.id,
          org: peerNode.org,
          country: peerNode.country,
          relationshipType: relationshipType,
          connectionSince: link.established || new Date(Date.now() - Math.random() * 3 * 365 * 24 * 60 * 60 * 1000).toISOString(),
          bandwidth: link.bandwidth || `${Math.floor(Math.random()*10)*10+10}G`
        });
      });
      // Add a few more mock peers if not enough from links
      if (keyPeers.length < 3) {
          const mockPeerTypes: KeyPeerInfo['relationshipType'][] = ['Transit Provider', 'Customer', 'Public Peer'];
          for(let i=keyPeers.length; i < 3; i++) {
            const randomOtherNode = INITIAL_ASN_DATA.nodes.find(n => n.id !== targetNode.id && !keyPeers.find(p=>p.asnId === n.id));
            if(randomOtherNode) {
                 keyPeers.push({
                    asnId: randomOtherNode.id,
                    org: randomOtherNode.org,
                    country: randomOtherNode.country,
                    relationshipType: mockPeerTypes[i % mockPeerTypes.length],
                    connectionSince: new Date(Date.now() - Math.random() * 5 * 365 * 24 * 60 * 60 * 1000).toISOString(),
                    bandwidth: `${Math.floor(Math.random()*5)*10+1}G`
                });
            }
          }
      }


      const recentBGPActivity: RecentBGPActivityInfo[] = MOCK_HISTORICAL_EVENTS
        .filter(event => event.involvedASNs.includes(targetNode.id))
        .slice(0, 3)
        .map(event => ({
          timestamp: event.timestamp,
          type: event.type,
          summary: event.description.substring(0, 100) + (event.description.length > 100 ? '...' : ''),
          relatedASNs: event.involvedASNs,
        }));
      if (recentBGPActivity.length < 2) {
          recentBGPActivity.push({
            timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
            type: 'prefix_update',
            summary: `Routine prefix advertisement update for 192.0.2.0/24.`,
            relatedPrefix: '192.0.2.0/24'
          });
      }

      const connectivityScore = Math.min(99, 50 + keyPeers.length * 5 + Math.floor(targetNode.customers / 10000));
      let securityPostureScore = 70;
      if (targetNode.threat === 'critical') securityPostureScore = 10;
      else if (targetNode.threat === 'high') securityPostureScore = 30;
      else if (targetNode.threat === 'medium') securityPostureScore = 50;
      const invalidPrefixes = announcedPrefixes.filter(p => p.rpkiStatus === 'invalid').length;
      securityPostureScore -= invalidPrefixes * 10;
      securityPostureScore = Math.max(5, securityPostureScore);


      const asnDetailedInfo: ASNDetailedInfo = {
        asn: targetNode,
        announcedPrefixes,
        keyPeers,
        recentBGPActivity,
        connectivityScore: connectivityScore,
        securityPostureScore: securityPostureScore,
        lastUpdated: new Date().toISOString(),
      };
      
      resolve(asnDetailedInfo);
    }, SIMULATED_ASN_DETAIL_DELAY);
  });
};
