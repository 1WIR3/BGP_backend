

import React, { useState, useEffect, useCallback, useRef } from 'react';
import Header from './components/Header';
import ControlPanel from './components/ControlPanel';
import BGPMap from './components/BGPMap';
import LiveThreatFeed from './components/LiveThreatFeed';
import ThreatSummary from './components/ThreatSummary';
import HistoricalTimeline from './components/HistoricalTimeline';
import ASPathAnalysis from './components/ASPathAnalysis';
import GeopoliticalAnalysis from './components/GeopoliticalAnalysis';
import RelationshipAnalysis from './components/RelationshipAnalysis'; 
import ASNPairAnalyzer from './components/ASNPairAnalyzer';
import ASNDetailView from './components/ASNDetailView'; // New component
import Tooltip from './components/Tooltip';
import IncidentLog from './components/IncidentLog';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

import { 
  ASNNode, BGPLink, AnalysisHistoryItem, LayoutMode, FeedEntryMessage, 
  ThreatSummaryData, HistoricalEvent, ASPathData, GeopoliticalInfo, TooltipData, ResolvedBGPLink,
  ASNPairAnalysisResult, ASPathSegment, BGPUpdateEvent, ASNDetailedInfo // Added ASNDetailedInfo
} from './types';
import { INITIAL_ASN_DATA, MOCK_HISTORICAL_EVENTS, GEOPOLITICAL_RISK_COUNTRIES } from './constants'; 
import { generateAdvancedBGPData, fetchASPathData, fetchMockBGPUpdates, fetchASNDetails } from './services/bgpService'; // Added fetchASNDetails

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const App: React.FC = () => {
  // Control Panel State
  const [targetIP, setTargetIP] = useState<string>('');
  const [analysisHistory, setAnalysisHistory] = useState<AnalysisHistoryItem[]>([]);
  const [detectHijacks, setDetectHijacks] = useState<boolean>(true);
  const [detectLeaks, setDetectLeaks] = useState<boolean>(true);
  const [detectGeopolitical, setDetectGeopolitical] = useState<boolean>(true);
  const [realTimeMonitoring, setRealTimeMonitoring] = useState<boolean>(false);
  const [layoutMode, setLayoutMode] = useState<LayoutMode>(LayoutMode.Force);
  const [timelineValue, setTimelineValue] = useState<number>(100); 
  const [timelineDate, setTimelineDate] = useState<string>('Now');
  const [feedRIPE, setFeedRIPE] = useState<boolean>(true);
  const [feedRouteViews, setFeedRouteViews] = useState<boolean>(true);
  const [feedThreatIntel, setFeedThreatIntel] = useState<boolean>(true);
  const [feedStatusActive, setFeedStatusActive] = useState<boolean>(true); 

  // BGP Map State
  const [bgpNodes, setBgpNodes] = useState<ASNNode[]>([]);
  const [bgpLinks, setBgpLinks] = useState<ResolvedBGPLink[]>([]);
  const [mapStatusText, setMapStatusText] = useState<string>('Initializing...');
  const [tooltipData, setTooltipData] = useState<TooltipData>({ visible: false, content: '', x: 0, y: 0, asn: undefined });

  // Analysis Panels State
  const [feedMessages, setFeedMessages] = useState<FeedEntryMessage[]>([
    { id: 'init', timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }), text: 'BGP monitoring systems initializing...', type: 'info' }
  ]);
  const [feedEventCount, setFeedEventCount] = useState<number>(0);
  const [incidentLogEntries, setIncidentLogEntries] = useState<FeedEntryMessage[]>([]);
  const [threatSummaryData, setThreatSummaryData] = useState<ThreatSummaryData[]>([]);
  const [historicalTimelineData, setHistoricalTimelineData] = useState<HistoricalEvent[]>([]);
  const [asPathData, setAsPathData] = useState<ASPathData[]>([]);
  const [geopoliticalData, setGeopoliticalData] = useState<GeopoliticalInfo[]>([]);
  const [selectedASN, setSelectedASN] = useState<ASNNode | null>(null);

  // ASN Detail View State
  const [asnDetailViewData, setAsnDetailViewData] = useState<ASNDetailedInfo | null>(null);
  const [isFetchingASNDetails, setIsFetchingASNDetails] = useState<boolean>(false);

  // ASN Pair Analyzer State
  const [sourceASNInput, setSourceASNInput] = useState<string>('');
  const [destinationASNInput, setDestinationASNInput] = useState<string>('');
  const [asnPairAnalysisResult, setAsnPairAnalysisResult] = useState<ASNPairAnalysisResult | null>(null);
  const [isPairAnalyzing, setIsPairAnalyzing] = useState<boolean>(false);


  const addFeedEntry = useCallback((text: string, type: FeedEntryMessage['type'] = 'info', timestamp?: string) => {
    const newEntry: FeedEntryMessage = { 
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: timestamp || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      text,
      type
    };
    setFeedMessages(prev => [...prev.slice(-99), newEntry]);
    if(type === 'critical-alert' || type === 'error' || type === 'warning') {
        setFeedEventCount(prev => prev + 1);
        const incidentTimestamp = timestamp ? new Date(new Date().toDateString() + ' ' + timestamp).getTime() : Date.now();
        setIncidentLogEntries(prev => [...prev.slice(-99), {...newEntry, timestamp: incidentTimestamp.toString() }].sort((a,b) => parseFloat(b.timestamp) - parseFloat(a.timestamp)));
    }
  }, []);

  const handleClearIncidentLog = useCallback(() => {
    setIncidentLogEntries([]);
    addFeedEntry('Incident log cleared.', 'info');
  }, [addFeedEntry]);

  const updateAnalysisPanels = useCallback((nodes: ASNNode[], links: ResolvedBGPLink[], targetNode?: ASNNode | null) => {
    const currentThreats: ThreatSummaryData[] = [];
    const currentHistoricalEvents: HistoricalEvent[] = [...MOCK_HISTORICAL_EVENTS]; 
    let currentAsPaths: ASPathData[] = [];
    const currentGeopoliticalInfo: GeopoliticalInfo[] = [];

    const nodesToAnalyze = targetNode ? [targetNode] : nodes;

    nodesToAnalyze.forEach(node => {
        let nodeThreatDescription = `Analysis for ${node.name} (${node.id}). Org: ${node.org}. Country: ${node.country}. Tier ${node.tier}. Customers: ${node.customers.toLocaleString()}.`;
        let nodeThreatLevel = node.threat;
        let nodeScore = node.threat === 'critical' ? 95 : node.threat === 'high' ? 80 : node.threat === 'medium' ? 60 : node.threat === 'low' ? 40 : 20;
        let hasActiveEvent = false;

        const relatedLinks = links.filter(l => l.source.id === node.id || l.target.id === node.id);

        if (detectHijacks) {
            const hijackLink = relatedLinks.find(l => l.type === 'hijack');
            if (hijackLink) {
                hasActiveEvent = true;
                nodeThreatLevel = 'critical';
                nodeScore = 98;
                const hijacker = hijackLink.source.id === node.id ? hijackLink.target : hijackLink.source;
                nodeThreatDescription = `[ACTIVE HIJACK] ${node.id} is involved in a BGP hijack event with ${hijacker.id} (${hijacker.org}). Prefixes may be illegitimately routed. Critical risk. RPKI likely invalid.`;
                currentHistoricalEvents.push({
                    id: `hijack-${node.id}-${hijacker.id}-${Date.now()}`, timestamp: new Date().toISOString(), date: new Date().toLocaleDateString(), time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    type: 'hijack', severity: 'critical', description: `Active BGP hijack: ${node.id} affected by ${hijacker.id}.`, involvedASNs: [node.id, hijacker.id]
                });
            }
        }

        if (detectLeaks && !hasActiveEvent) { 
            const leakLink = relatedLinks.find(l => l.type === 'leak');
            if (leakLink) {
                hasActiveEvent = true;
                nodeThreatLevel = 'high';
                nodeScore = 85;
                const leaker = leakLink.source.id === node.id ? leakLink.target : leakLink.source;
                nodeThreatDescription = `[ACTIVE LEAK] ${node.id} is involved in a route leak event with ${leaker.id} (${leaker.org}). Internal routes may be exposed. High risk.`;
                 currentHistoricalEvents.push({
                    id: `leak-${node.id}-${leaker.id}-${Date.now()}`, timestamp: new Date().toISOString(), date: new Date().toLocaleDateString(), time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    type: 'leak', severity: 'warning', description: `Active route leak: ${node.id} affected by ${leaker.id}.`, involvedASNs: [node.id, leaker.id]
                });
            }
        }
        
        if (targetNode || (nodeThreatLevel !== 'clean' && nodeThreatLevel !== 'unknown') || hasActiveEvent) {
             currentThreats.push({
                id: node.id, asn: node.id, org: node.org, country: node.country, score: nodeScore,
                threatLevel: nodeThreatLevel, description: nodeThreatDescription, relatedEvents: relatedLinks.length,
            });
        }

        if (targetNode && node.id === targetNode.id) {
             const pathSegmentsNodes: ASNNode[] = [
                nodes.find(n => n.id === "AS174") || INITIAL_ASN_DATA.nodes.find(n=>n.id==="AS174")!, 
                targetNode
            ];
            const pathSegments: ASPathSegment[] = pathSegmentsNodes.map(n => ({ 
                asn: n.id, org: n.org, country: n.country, 
                isRpkiValid: n.threat !== 'high' && n.threat !== 'critical', 
                isSuspectedHijacker: n.threat === 'critical' || (hasActiveEvent && nodeThreatLevel==='critical')
            }));
            
            if (pathSegments.length >=2) {
                 currentAsPaths.push({
                    id: `path-to-${targetNode.id}-${Date.now()}`, sourceAS: pathSegments[0].asn, destinationPrefix: `Prefix towards ${targetNode.id}`, path: pathSegments,
                    isPotentiallyHijacked: targetNode.threat === 'critical' || (hasActiveEvent && nodeThreatLevel==='critical'), 
                    isRouteLeak: targetNode.threat === 'high' && !pathSegments.some(p => p.isSuspectedHijacker)  || (hasActiveEvent && nodeThreatLevel==='high')
                });
            }
        }

        if (detectGeopolitical && (GEOPOLITICAL_RISK_COUNTRIES.includes(node.country) || node.threat === 'critical' || node.threat === 'high' || relatedLinks.some(l => l.geopolitical))) {
            let riskReason = `Traffic involving ${node.id} (${node.country}).`;
            if (GEOPOLITICAL_RISK_COUNTRIES.includes(node.country)) riskReason += ` Country ${node.country} flagged for geopolitical monitoring.`;
            if (node.threat === 'critical' || node.threat === 'high') riskReason += ` High threat level observed for ASN.`;
            if (hasActiveEvent && nodeThreatLevel === 'critical') riskReason += ` Involved in active BGP hijack.`;
            else if (hasActiveEvent && nodeThreatLevel === 'high') riskReason += ` Involved in active route leak.`;

            currentGeopoliticalInfo.push({
                id: node.id, asn: node.id, country: node.country,
                riskFactor: nodeThreatLevel === 'critical' ? 'high' : (nodeThreatLevel === 'high' || GEOPOLITICAL_RISK_COUNTRIES.includes(node.country) ? 'medium' : 'low'),
                details: riskReason,
                relatedLinks: relatedLinks.filter(l => l.geopolitical).map(l => ({ source: l.source.id, target: l.target.id, reason: "Link flagged with geopolitical sensitivity" }))
            });
        }
    });
    
    if (!targetNode && currentThreats.length === 0) {
        INITIAL_ASN_DATA.nodes.filter(n => n.threat === 'critical' || n.threat === 'high').slice(0, 2)
            .forEach(n => {
                currentThreats.push({
                    id: n.id, asn: n.id, org: n.org, country: n.country, score: n.threat === 'critical' ? 95 : 80, 
                    threatLevel: n.threat, description: `General high threat associated with ${n.name} (${n.id}).`, 
                    relatedEvents: INITIAL_ASN_DATA.links.filter(l => (typeof l.source === 'string' ? l.source : l.source.id) === n.id || (typeof l.target === 'string' ? l.target : l.target.id) === n.id).length
                });
            });
    }

    setThreatSummaryData(currentThreats.sort((a,b) => b.score - a.score).slice(0, targetNode ? 3 : 5));
    setHistoricalTimelineData(
        (targetNode ? currentHistoricalEvents.filter(event => event.involvedASNs.includes(targetNode.id)) : currentHistoricalEvents)
        .sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    );
    setAsPathData(currentAsPaths.slice(0, 5)); 
    setGeopoliticalData(currentGeopoliticalInfo.slice(0, targetNode ? 3 : 5));

  }, [detectHijacks, detectLeaks, detectGeopolitical]);


  const resolveAndSetLinks = useCallback((newLinksData: BGPLink[], nodeMap: Map<string, ASNNode>) => {
    const resolvedLinks = newLinksData.map((link, index) => {
        const sourceNode = nodeMap.get(typeof link.source === 'string' ? link.source : link.source.id);
        const targetNode = nodeMap.get(typeof link.target === 'string' ? link.target : link.target.id);
        if (!sourceNode || !targetNode) return null; 
        return {
            id: link.id || `link-${index}-${sourceNode.id}-${targetNode.id}-${link.type}`,
            ...link,
            source: sourceNode,
            target: targetNode,
        };
    }).filter(link => link !== null) as ResolvedBGPLink[];
    setBgpLinks(resolvedLinks);
    return resolvedLinks;
  }, []);

  const fetchAndSetASNDetails = async (node: ASNNode) => {
    setIsFetchingASNDetails(true);
    setAsnDetailViewData(null); // Clear previous details
    try {
      const details = await fetchASNDetails(node.id, bgpNodes, bgpLinks);
      setAsnDetailViewData(details);
      if (details) {
        addFeedEntry(`Loaded detailed information for ${node.id}.`, 'info');
      } else {
        addFeedEntry(`Could not load detailed information for ${node.id}.`, 'warning');
      }
    } catch (error) {
      console.error(`Error fetching ASN details for ${node.id}:`, error);
      addFeedEntry(`Error fetching details for ${node.id}: ${(error as Error).message}`, 'error');
      setAsnDetailViewData(null);
    } finally {
      setIsFetchingASNDetails(false);
    }
  };


  const fetchDataForTarget = useCallback(async (targetQuery?: string) => {
    setMapStatusText('Loading...');
    setSelectedASN(null);
    setAsnDetailViewData(null); // Clear detailed view on new general query
    try {
      const { nodes: rawNewNodes, links: newLinksData } = await generateAdvancedBGPData(targetQuery);
      
      const newNodesForState = rawNewNodes.map(n => ({...n}));
      const nodeMap = new Map(newNodesForState.map(n => [n.id, n])); 
      setBgpNodes(newNodesForState); 
      
      const resolvedLinksResult = resolveAndSetLinks(newLinksData, nodeMap);

      let currentTargetNode: ASNNode | undefined = undefined;
      if (targetQuery && newNodesForState.length > 0) {
        const targetQueryLower = targetQuery.toLowerCase();
        currentTargetNode = newNodesForState.find(n => 
            n.id.toLowerCase() === targetQueryLower || 
            (n.name && n.name.toLowerCase().includes(targetQueryLower)) ||
            (n.org && n.org.toLowerCase().includes(targetQueryLower))
        );
      }
      
      setSelectedASN(currentTargetNode || null); 
      if (currentTargetNode) {
        fetchAndSetASNDetails(currentTargetNode);
      }
      
      if (newNodesForState.length === 0 && targetQuery) {
        addFeedEntry(`Target "${targetQuery}" not found or has no displayable data. Map cleared.`, 'warning');
        setMapStatusText(`Not Found: ${targetQuery}`);
      } else {
        setMapStatusText(targetQuery ? `Analysis: ${currentTargetNode?.name || targetQuery}` : 'Live Overview');
      }
      updateAnalysisPanels(newNodesForState, resolvedLinksResult, currentTargetNode);

    } catch (error) {
      console.error("Failed to fetch BGP data:", error);
      setMapStatusText('Error loading data');
      addFeedEntry(`Error fetching data for ${targetQuery || 'overview'}: ${(error as Error).message}`, 'error');
      setBgpNodes([]);
      setBgpLinks([]);
      updateAnalysisPanels([], [], null);
    }
  }, [addFeedEntry, updateAnalysisPanels, resolveAndSetLinks]); // bgpNodes, bgpLinks removed from deps to avoid loop with fetchAndSetASNDetails
  
  useEffect(() => {
    fetchDataForTarget(undefined);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 
  
  useEffect(() => {
    let intervalId: number | undefined;
    if (realTimeMonitoring && bgpNodes.length > 0) {
        setMapStatusText('Live Monitoring Active');
        addFeedEntry('Live monitoring started.', 'success');

        intervalId = window.setInterval(async () => {
            const events = await fetchMockBGPUpdates(bgpNodes, bgpLinks);
            let linksChanged = false;
            const newNodeMap = new Map(bgpNodes.map(n => [n.id, n]));

            events.forEach(event => {
                const eventTime = new Date(event.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                addFeedEntry(event.description, event.severity, eventTime);

                let newLink: BGPLink | null = null;
                let linkToRemove: {sourceId: string, targetId: string, type: BGPLink['type']} | null = null;

                switch (event.type) {
                    case 'new_hijack':
                        if (event.sourceAS && event.targetAS && detectHijacks) {
                            newLink = { source: event.sourceAS, target: event.targetAS, type: 'hijack', suspicious: true, bandwidth: "N/A", established: new Date().toISOString() };
                        }
                        break;
                    case 'new_leak':
                        if (event.sourceAS && event.targetAS && detectLeaks) {
                             newLink = { source: event.sourceAS, target: event.targetAS, type: 'leak', suspicious: true, bandwidth: "N/A", established: new Date().toISOString() };
                        }
                        break;
                    case 'new_peering':
                        if (event.sourceAS && event.targetAS) {
                            newLink = { source: event.sourceAS, target: event.targetAS, type: 'peer', suspicious: false, bandwidth: "N/A", established: new Date().toISOString() };
                        }
                        break;
                    case 'peering_down':
                         if (event.sourceAS && event.targetAS) {
                            linkToRemove = {sourceId: event.sourceAS, targetId: event.targetAS, type: 'peer'};
                        }
                        break;
                }

                if (newLink) {
                    const sourceNode = newNodeMap.get(newLink.source as string);
                    const targetNode = newNodeMap.get(newLink.target as string);
                    if (sourceNode && targetNode) {
                        const resolvedNewLink: ResolvedBGPLink = {
                            ...newLink,
                            id: `dynlink-${Date.now()}-${sourceNode.id}-${targetNode.id}`,
                            source: sourceNode,
                            target: targetNode
                        };
                        const linkExists = bgpLinks.some(l => 
                            ((l.source.id === resolvedNewLink.source.id && l.target.id === resolvedNewLink.target.id) ||
                             (l.source.id === resolvedNewLink.target.id && l.target.id === resolvedNewLink.source.id)) &&
                            l.type === resolvedNewLink.type
                        );
                        if (!linkExists) {
                           setBgpLinks(prevLinks => [...prevLinks, resolvedNewLink]);
                           linksChanged = true;
                        }
                    }
                }
                if (linkToRemove) {
                    setBgpLinks(prevLinks => prevLinks.filter(l => 
                        !(
                            ((l.source.id === linkToRemove!.sourceId && l.target.id === linkToRemove!.targetId) ||
                             (l.source.id === linkToRemove!.targetId && l.target.id === linkToRemove!.sourceId)) &&
                            l.type === linkToRemove!.type
                        )
                    ));
                    linksChanged = true;
                }
            });

            if (linksChanged) {
                 updateAnalysisPanels(bgpNodes, bgpLinks, selectedASN);
                 if (selectedASN) { // Re-fetch details if selected ASN's links might have changed
                    fetchAndSetASNDetails(selectedASN);
                 }
            }
        }, 7000);

    } else {
        if (intervalId) clearInterval(intervalId);
        if (mapStatusText === 'Live Monitoring Active' || mapStatusText === 'Initializing...') {
            setMapStatusText(selectedASN ? `Focus: ${selectedASN.name || selectedASN.id}` : 'Live Overview');
        }
        const lastMessage = feedMessages[feedMessages.length - 1];
        if (lastMessage && lastMessage.text === 'Live monitoring started.') {
            addFeedEntry('Live monitoring stopped.', 'info');
        }
    }
    return () => clearInterval(intervalId);
  }, [realTimeMonitoring, bgpNodes, bgpLinks, addFeedEntry, mapStatusText, detectHijacks, detectLeaks, updateAnalysisPanels, selectedASN]);


  const analyzeTargetHandler = () => {
    if (!targetIP.trim()) { 
      addFeedEntry('Displaying general BGP overview.', 'info');
      fetchDataForTarget(undefined); 
      setAnalysisHistory(prev => [{ id: Date.now().toString(), query: 'General Overview', timestamp: Date.now() }, ...prev.slice(0, 9)].sort((a,b) => b.timestamp - a.timestamp));
      return;
    }
    addFeedEntry(`Analyzing target: ${targetIP}...`, 'info');
    fetchDataForTarget(targetIP);
    setAnalysisHistory(prev => [{ id: Date.now().toString(), query: targetIP, timestamp: Date.now() }, ...prev.slice(0, 9)].sort((a,b) => b.timestamp - a.timestamp));
  };

  const loadHistoricalAnalysisHandler = (id: string) => {
    const historyItem = analysisHistory.find(item => item.id === id);
    if (historyItem) {
      const queryForFetch = historyItem.query === 'General Overview' ? undefined : historyItem.query;
      setTargetIP(queryForFetch || '');
      addFeedEntry(`Loading historical analysis: ${historyItem.query}`, 'info');
      fetchDataForTarget(queryForFetch);
    }
  };

  const handleNodeClickHandler = (node: ASNNode) => {
    setSelectedASN(node);
    setTargetIP(node.id); 
    addFeedEntry(`Selected ASN: ${node.id} (${node.name}). Displaying details.`, 'info');
    updateAnalysisPanels(bgpNodes, bgpLinks, node);
    fetchAndSetASNDetails(node);
    setMapStatusText(`Focus: ${node.name || node.id}`);
  };
  
  const resetViewHandler = () => {
    addFeedEntry('View reset to default.', 'info');
    setTargetIP('');
    fetchDataForTarget(undefined); 
    setSourceASNInput('');
    setDestinationASNInput('');
    setAsnPairAnalysisResult(null);
    setSelectedASN(null);
    setAsnDetailViewData(null);
  };

  const exportAnalysisHandler = () => { 
    addFeedEntry('Export Analysis (JSON) feature not yet implemented.', 'warning');
  };
  const exportGraphImageHandler = () => { 
      addFeedEntry('Export Graph Image (SVG) feature not yet implemented.', 'warning');
  }; 
  const exportDataReportHandler = () => { 
      addFeedEntry('Export Data Report (TXT) feature not yet implemented.', 'warning');
  }; 
  const toggleFullscreenHandler = () => { 
      addFeedEntry('Toggle Fullscreen feature not yet implemented.', 'warning');
  }; 
  
  useEffect(() => {
    if (timelineValue === 100) setTimelineDate('Now');
    else if (timelineValue === 0) setTimelineDate('Oldest');
    else setTimelineDate(`${timelineValue}%`);
  }, [timelineValue]);

  useEffect(() => {
    setFeedStatusActive(feedRIPE || feedRouteViews || feedThreatIntel);
  }, [feedRIPE, feedRouteViews, feedThreatIntel]);

  const isInitialMountFeedRIPE = useRef(true);
  useEffect(() => {
      if (isInitialMountFeedRIPE.current) {
          isInitialMountFeedRIPE.current = false;
          if (feedRIPE && realTimeMonitoring) addFeedEntry('RIPE NCC data feed connected (simulated).', 'info');
      } else {
          if (realTimeMonitoring) addFeedEntry(`RIPE NCC data feed ${feedRIPE ? 'connected' : 'disconnected'} (simulated).`, 'info');
      }
  }, [feedRIPE, realTimeMonitoring, addFeedEntry]);

  const isInitialMountFeedRouteViews = useRef(true);
  useEffect(() => {
      if (isInitialMountFeedRouteViews.current) {
          isInitialMountFeedRouteViews.current = false;
          if (feedRouteViews && realTimeMonitoring) addFeedEntry('RouteViews data stream active (simulated).', 'info');
      } else {
         if (realTimeMonitoring) addFeedEntry(`RouteViews data stream ${feedRouteViews ? 'active' : 'disconnected'} (simulated).`, 'info');
      }
  }, [feedRouteViews, realTimeMonitoring, addFeedEntry]);

  const isInitialMountFeedThreatIntel = useRef(true);
  useEffect(() => {
      if (isInitialMountFeedThreatIntel.current) {
          isInitialMountFeedThreatIntel.current = false;
          if (feedThreatIntel && realTimeMonitoring) addFeedEntry('Threat Intelligence feed activated (simulated).', 'success');
      } else {
          if (realTimeMonitoring) addFeedEntry(`Threat Intelligence feed ${feedThreatIntel ? 'activated' : 'deactivated'} (simulated).`, feedThreatIntel ? 'success' : 'info');
      }
  }, [feedThreatIntel, realTimeMonitoring, addFeedEntry]);


  const handleAnalyzeThreatWithGemini = async (threatId: string) => {
    const threatIndex = threatSummaryData.findIndex(t => t.id === threatId);
    if (threatIndex === -1) return;
    const threatToAnalyze = threatSummaryData[threatIndex];
    setThreatSummaryData(prev => prev.map(t => t.id === threatId ? { ...t, isGeminiAnalyzing: true, geminiAnalysis: undefined } : t));
    addFeedEntry(`Requesting Gemini analysis for AS${threatToAnalyze.asn}...`, 'info');
    
    let eventContext = "";
    if (detectHijacks && threatToAnalyze.description.includes("[ACTIVE HIJACK]")) {
        eventContext = "This ASN is currently involved in an active BGP Hijack event. ";
    } else if (detectLeaks && threatToAnalyze.description.includes("[ACTIVE LEAK]")) {
        eventContext = "This ASN is currently involved in an active Route Leak event. ";
    }

    const prompt = `Provide a brief security analysis for an Autonomous System with the following details:
ASN: ${threatToAnalyze.asn}, Organization: ${threatToAnalyze.org}, Country: ${threatToAnalyze.country}, Threat Level: ${threatToAnalyze.threatLevel}.
${eventContext}Current Situation: ${threatToAnalyze.description}
Focus on potential risks, common concerns associated with this situation, and suggest one actionable mitigation step. Keep the response concise, maximum 3-4 sentences.`;
    
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({ model: 'gemini-2.5-flash-preview-04-17', contents: prompt });
        setThreatSummaryData(prev => prev.map(t => t.id === threatId ? { ...t, geminiAnalysis: response.text, isGeminiAnalyzing: false } : t));
        addFeedEntry(`Gemini analysis complete for AS${threatToAnalyze.asn}.`, 'success');
    } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Unknown Gemini error.";
        setThreatSummaryData(prev => prev.map(t => t.id === threatId ? { ...t, geminiAnalysis: `Error: ${errorMessage}`, isGeminiAnalyzing: false } : t));
        addFeedEntry(`Error during Gemini analysis for AS${threatToAnalyze.asn}: ${errorMessage}`, 'error');
    }
  };

  const handleAnalyzeASNDetailsWithGemini = async (asnId: string, dataToAnalyze: ASNDetailedInfo) => {
    if (!dataToAnalyze) return;

    setAsnDetailViewData(prev => prev ? { ...prev, isGeminiAnalyzing: true, geminiAnalysis: undefined } : null);
    addFeedEntry(`Requesting Gemini analysis for detailed view of ${asnId}...`, 'info');

    const prefixSummary = dataToAnalyze.announcedPrefixes.slice(0,3).map(p => `${p.prefix} (RPKI: ${p.rpkiStatus})`).join(', ');
    const peerSummary = dataToAnalyze.keyPeers.slice(0,3).map(p => `${p.asnId} (${p.relationshipType})`).join(', ');
    const activitySummary = dataToAnalyze.recentBGPActivity.slice(0,2).map(a => `${a.type}: ${a.summary.substring(0,30)}...`).join('; ');

    const prompt = `Provide a concise (3-4 sentences) expert BGP analysis for ${dataToAnalyze.asn.id} (${dataToAnalyze.asn.org}, ${dataToAnalyze.asn.country}).
Connectivity Score: ${dataToAnalyze.connectivityScore}/100. Security Posture: ${dataToAnalyze.securityPostureScore}/100.
Key Prefixes: ${prefixSummary || 'N/A'}.
Key Peers: ${peerSummary || 'N/A'}.
Recent Activity: ${activitySummary || 'N/A'}.
Highlight key characteristics, potential risks, and overall stability based on this data.`;

    try {
      const response: GenerateContentResponse = await ai.models.generateContent({ model: 'gemini-2.5-flash-preview-04-17', contents: prompt });
      setAsnDetailViewData(prev => prev ? { ...prev, geminiAnalysis: response.text, isGeminiAnalyzing: false } : null);
      addFeedEntry(`Gemini analysis complete for detailed view of ${asnId}.`, 'success');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown Gemini error.";
      setAsnDetailViewData(prev => prev ? { ...prev, geminiAnalysis: `Error: ${errorMessage}`, isGeminiAnalyzing: false } : null);
      addFeedEntry(`Error during Gemini analysis for detailed view of ${asnId}: ${errorMessage}`, 'error');
    }
  };


  const handleAnalyzeASNPair = useCallback(async () => {
    if (!sourceASNInput.trim() || !destinationASNInput.trim()) {
      setAsnPairAnalysisResult({ error: "Please enter both Source and Destination ASNs.", timestamp: Date.now() });
      return;
    }
    setIsPairAnalyzing(true);
    addFeedEntry(`Analyzing paths between ${sourceASNInput.trim().toUpperCase()} and ${destinationASNInput.trim().toUpperCase()}...`, 'info');

    try {
      const sourceId = sourceASNInput.trim().toUpperCase();
      const destinationId = destinationASNInput.trim().toUpperCase();

      const fetchedPaths = await fetchASPathData(
        sourceId,
        destinationId,
        bgpNodes 
      );

      const sourceNode = bgpNodes.find(n => n.id === sourceId) || INITIAL_ASN_DATA.nodes.find(n => n.id === sourceId);
      const destinationNode = bgpNodes.find(n => n.id === destinationId) || INITIAL_ASN_DATA.nodes.find(n => n.id === destinationId);

      if (!sourceNode || !destinationNode) {
        setAsnPairAnalysisResult({ error: "One or both ASNs not found in available datasets.", timestamp: Date.now() });
        addFeedEntry(`Pair analysis error: ASN ${sourceId} or ${destinationId} not found.`, 'error');
        setIsPairAnalyzing(false);
        return;
      }
      
      const directLinks = bgpLinks.filter(
        link => (link.source.id === sourceNode.id && link.target.id === destinationNode.id) ||
                (link.source.id === destinationNode.id && link.target.id === sourceNode.id)
      );

      setAsnPairAnalysisResult({
        sourceNode,
        destinationNode,
        directLinks: directLinks.length > 0 ? directLinks : undefined,
        paths: fetchedPaths.length > 0 ? fetchedPaths : undefined,
        timestamp: Date.now()
      });
      addFeedEntry(`Path analysis complete for ${sourceId} - ${destinationId}. Found ${fetchedPaths.length} path(s).`, 'success');

    } catch (error) {
      console.error("Error fetching AS Path data:", error);
      const errorMessage = error instanceof Error ? error.message : "Unknown error during path analysis.";
      setAsnPairAnalysisResult({ error: `Path analysis failed: ${errorMessage}`, timestamp: Date.now() });
      addFeedEntry(`Error during path analysis for ${sourceASNInput.trim().toUpperCase()} - ${destinationASNInput.trim().toUpperCase()}: ${errorMessage}`, 'error');
    } finally {
      setIsPairAnalyzing(false);
    }
  }, [sourceASNInput, destinationASNInput, bgpNodes, bgpLinks, addFeedEntry]);


  const selectedASNInfo = selectedASN ? { id: selectedASN.id, name: selectedASN.name, country: selectedASN.country, org: selectedASN.org } : null;

  useEffect(() => {
    updateAnalysisPanels(bgpNodes, bgpLinks, selectedASN);
    if (selectedASN && !isFetchingASNDetails && (!asnDetailViewData || asnDetailViewData.asn.id !== selectedASN.id)) {
        // This condition ensures we fetch details if an ASN is selected,
        // details are not currently being fetched,
        // and either no details are loaded OR the loaded details are for a different ASN.
        fetchAndSetASNDetails(selectedASN);
    } else if (!selectedASN && asnDetailViewData) {
        // Clear details if no ASN is selected anymore
        setAsnDetailViewData(null);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [detectHijacks, detectLeaks, detectGeopolitical, bgpNodes, bgpLinks, selectedASN, updateAnalysisPanels]);


  return (
    <div className="flex flex-col min-h-screen bg-slate-100">
      <Header />
      <main className="container mx-auto px-4 py-6 flex-grow w-full max-w-full">
        <ControlPanel
          targetIP={targetIP} setTargetIP={setTargetIP} analyzeTarget={analyzeTargetHandler}
          analysisHistory={analysisHistory} loadHistoricalAnalysis={loadHistoricalAnalysisHandler}
          detectHijacks={detectHijacks} setDetectHijacks={setDetectHijacks}
          detectLeaks={detectLeaks} setDetectLeaks={setDetectLeaks}
          detectGeopolitical={detectGeopolitical} setDetectGeopolitical={setDetectGeopolitical}
          realTimeMonitoring={realTimeMonitoring} setRealTimeMonitoring={setRealTimeMonitoring}
          layoutMode={layoutMode} setLayoutMode={setLayoutMode}
          timelineValue={timelineValue} setTimelineValue={setTimelineValue} timelineDate={timelineDate}
          resetView={resetViewHandler} 
          exportAnalysis={exportAnalysisHandler}
          exportGraphImage={exportGraphImageHandler}
          exportDataReport={exportDataReportHandler}
          toggleFullscreen={toggleFullscreenHandler}
          feedRIPE={feedRIPE} setFeedRIPE={setFeedRIPE}
          feedRouteViews={feedRouteViews} setFeedRouteViews={setFeedRouteViews}
          feedThreatIntel={feedThreatIntel} setFeedThreatIntel={setFeedThreatIntel}
          feedStatusActive={feedStatusActive}
        />

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mt-6">
          <div className="xl:col-span-2 h-[600px] md:h-[700px] xl:h-[calc(100vh-280px)] min-h-[500px]"> 
            <BGPMap 
              nodesData={bgpNodes} 
              linksData={bgpLinks} 
              mapStatusText={mapStatusText}
              onNodeClick={handleNodeClickHandler}
              setTooltipData={setTooltipData}
            />
          </div>

          <div className="space-y-6 xl:max-h-[calc(100vh-280px)] xl:overflow-y-auto analysis-panel pr-1">
            <LiveThreatFeed feedMessages={feedMessages} feedEventCount={feedEventCount} />
            <IncidentLog incidentLogEntries={incidentLogEntries} clearIncidentLog={handleClearIncidentLog} />
            {(selectedASN || isFetchingASNDetails) && ( // Conditionally render ASNDetailView
                 <ASNDetailView
                    detailData={asnDetailViewData}
                    isLoading={isFetchingASNDetails}
                    onAnalyzeWithGemini={handleAnalyzeASNDetailsWithGemini}
                    selectedASNInfo={selectedASNInfo} 
                 />
            )}
            <ASNPairAnalyzer
              sourceASNInput={sourceASNInput}
              destinationASNInput={destinationASNInput}
              onSetSourceASNInput={setSourceASNInput}
              onSetDestinationASNInput={setDestinationASNInput}
              onAnalyzePair={handleAnalyzeASNPair}
              analysisResult={asnPairAnalysisResult}
              isLoading={isPairAnalyzing}
            />
            <ThreatSummary 
              threatData={threatSummaryData} 
              onAnalyzeWithGemini={handleAnalyzeThreatWithGemini}
              selectedASNInfo={selectedASNInfo}
            />
            <HistoricalTimeline 
              timelineData={historicalTimelineData} 
              selectedASNInfo={selectedASNInfo}
            />
            <ASPathAnalysis 
              asPathData={asPathData} 
              selectedASNInfo={selectedASNInfo}
            />
            <RelationshipAnalysis 
              key={selectedASNInfo ? selectedASNInfo.id : 'no-asn-selected'}
              selectedASNInfo={selectedASNInfo}
              allLinks={bgpLinks}
            />
            <GeopoliticalAnalysis 
              geoData={geopoliticalData} 
              selectedASNInfo={selectedASNInfo}
            />
          </div>
        </div>
      </main>
      <Tooltip tooltipData={tooltipData} />
      <footer className="text-center py-4 text-sm text-slate-500 border-t border-slate-200 bg-slate-50">
        BGP Threat Intelligence Mapper &copy; {new Date().getFullYear()}
      </footer>
    </div>
  );
};

export default App;
