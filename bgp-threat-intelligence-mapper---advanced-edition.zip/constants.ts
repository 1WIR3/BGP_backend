
import { ThreatLegendItem, ASNNode, LinkLegendItem, BGPLink, HistoricalEvent } from './types';

export const COUNTRY_FLAGS: { [key: string]: string } = {
    'US': '🇺🇸', 'CN': '🇨🇳', 'RU': '🇷🇺', 'DE': '🇩🇪', 'GB': '🇬🇧',
    'FR': '🇫🇷', 'JP': '🇯🇵', 'KR': '🇰🇷', 'IN': '🇮🇳', 'BR': '🇧🇷',
    'CA': '🇨🇦', 'AU': '🇦🇺', 'NL': '🇳🇱', 'SE': '🇸🇪', 'CH': '🇨🇭',
    'KP': '🇰🇵', 'IR': '🇮🇷', 'SY': '🇸🇾',
    '??': '🏴‍☠️', 'XX': '❓' // Unknown / Pirate
};

export const GEOPOLITICAL_RISK_COUNTRIES: string[] = ['CN', 'RU', 'KP', 'IR', 'SY'];

export const THREAT_LEVELS: ThreatLegendItem[] = [
    { level: 'critical', label: 'Critical', colorClass: 'bg-red-700' },
    { level: 'high', label: 'High', colorClass: 'bg-red-500' },
    { level: 'medium', label: 'Medium', colorClass: 'bg-orange-500' },
    { level: 'low', label: 'Low', colorClass: 'bg-yellow-400' },
    { level: 'clean', label: 'Clean', colorClass: 'bg-green-500' },
];

export const LINK_LEGEND_ITEMS: LinkLegendItem[] = [
    { type: 'hijack-display', label: 'Hijacking', colorClass: 'text-red-600', lineStyle: '━━' }, // Used #dc2626 which is red-600
    { type: 'leak-display', label: 'Route Leak', colorClass: 'text-amber-500', lineStyle: '┈┈' }, // Used #f59e0b which is amber-500
    { type: 'peer', label: 'Peering', colorClass: 'text-blue-500', lineStyle: '──' },
    { type: 'transit', label: 'Transit', colorClass: 'text-purple-500', lineStyle: '──' },
    { type: 'geopolitical', label: 'Geopolitical', colorClass: 'text-red-500', lineStyle: '〰' }, // Used #ef4444 which is red-500
];

export const INITIAL_ASN_DATA: { nodes: ASNNode[]; links: BGPLink[] } = {
    nodes: [
        { id: "AS13335", name: "Cloudflare", threat: "clean", country: "US", org: "Cloudflare Inc", tier: 1, customers: 150000 },
        { id: "AS15169", name: "Google", threat: "clean", country: "US", org: "Google LLC", tier: 1, customers: 200000 },
        { id: "AS32934", name: "Facebook", threat: "clean", country: "US", org: "Meta Platforms Inc", tier: 1, customers: 80000 },
        { id: "AS7922", name: "Comcast", threat: "clean", country: "US", org: "Comcast Cable Communications", tier: 2, customers: 50000 },
        { id: "AS174", name: "Cogent", threat: "clean", country: "US", org: "Cogent Communications", tier: 1, customers: 300000 },
        { id: "AS4134", name: "ChinaTelecom", threat: "medium", country: "CN", org: "China Telecom", tier: 1, customers: 400000 }, // Target of Hijack by AS64515
        { id: "AS12389", name: "Rostelecom", threat: "medium", country: "RU", org: "Rostelecom", tier: 1, customers: 180000 }, // Target of Leak by AS64514
        { id: "AS64512", name: "DarkNet-AS", threat: "critical", country: "XX", org: "Unknown Bulletproof Entity", tier: 3, customers: 50 },
        { id: "AS64513", name: "ProxyHost", threat: "high", country: "??", org: "Anonymized Hosting Ltd", tier: 3, customers: 200 },
        { id: "AS64514", name: "LeakSource", threat: "high", country: "RU", org: "Route Leak Generator Corp", tier: 3, customers: 150 }, // Source of Leak
        { id: "AS64515", name: "HijackNet", threat: "critical", country: "CN", org: "BGP Manipulation Service", tier: 3, customers: 80 }, // Source of Hijack
        { id: "AS64516", name: "GeoBypass", threat: "high", country: "IR", org: "Sanctions Evasion Network", tier: 3, customers: 120 }
    ],
    links: [
        { source: "AS13335", target: "AS174", type: "transit", suspicious: false, bandwidth: "100G", established: "2015-03-15" },
        { source: "AS15169", target: "AS174", type: "transit", suspicious: false, bandwidth: "400G", established: "2012-08-22" },
        { source: "AS32934", target: "AS174", type: "transit", suspicious: false, bandwidth: "200G", established: "2016-11-08" },
        { source: "AS7922", target: "AS174", type: "transit", suspicious: false, bandwidth: "50G", established: "2010-05-12" },
        { source: "AS13335", target: "AS15169", type: "peer", suspicious: false, bandwidth: "10G", established: "2018-01-30" },
        { source: "AS64512", target: "AS174", type: "transit", suspicious: true, bandwidth: "1G", established: "2024-12-01" },
        { source: "AS64513", target: "AS64512", type: "peer", suspicious: true, bandwidth: "500M", established: "2024-11-15" },
        { source: "AS64514", target: "AS12389", type: "leak", suspicious: true, bandwidth: "2G", established: "2024-10-20" }, // Leak by AS64514 towards AS12389
        { source: "AS64515", target: "AS4134", type: "hijack", suspicious: true, bandwidth: "5G", established: "2024-12-10" }, // Hijack by AS64515 of AS4134 prefixes
        { source: "AS64516", target: "AS4134", type: "geopolitical", suspicious: true, bandwidth: "1G", established: "2024-11-28", geopolitical: true },
        { source: "AS4134", target: "AS174", type: "transit", suspicious: false, bandwidth: "100G", established: "2008-03-15", geopolitical: true },
        { source: "AS12389", target: "AS174", type: "transit", suspicious: false, bandwidth: "80G", established: "2009-07-20", geopolitical: true }
    ]
};

// Mock historical events - enhanced for Phase 4
export const MOCK_HISTORICAL_EVENTS: HistoricalEvent[] = [
    { 
        id: 'evt-hijack-1', 
        timestamp: new Date(Date.now() - 2 * 3600 * 1000).toISOString(), // 2 hours ago
        date: new Date(Date.now() - 2 * 3600 * 1000).toLocaleDateString(), 
        time: new Date(Date.now() - 2 * 3600 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), 
        type: 'hijack', 
        severity: 'critical', 
        description: 'Ongoing BGP Hijack: AS64515 (HijackNet) is redirecting traffic for prefixes normally announced by AS4134 (ChinaTelecom). RPKI Invalid.',
        involvedASNs: ['AS64515', 'AS4134'] 
    },
    { 
        id: 'evt-leak-1', 
        timestamp: new Date(Date.now() - 5 * 3600 * 1000).toISOString(), // 5 hours ago
        date: new Date(Date.now() - 5 * 3600 * 1000).toLocaleDateString(),
        time: new Date(Date.now() - 5 * 3600 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: 'leak', 
        severity: 'warning', 
        description: 'Route Leak Detected: AS64514 (LeakSource) is propagating internal routes from AS12389 (Rostelecom) to its transit providers.',
        involvedASNs: ['AS64514', 'AS12389'] 
    },
    { 
        id: 'evt-security-1', 
        timestamp: new Date(Date.now() - 24 * 3600 * 1000).toISOString(), // 1 day ago
        date: new Date(Date.now() - 24 * 3600 * 1000).toLocaleDateString(),
        time: new Date(Date.now() - 24 * 3600 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: 'security_incident', 
        severity: 'warning', 
        description: 'Suspicious routing activity observed from AS64512 (DarkNet-AS) towards multiple Tier-1 providers. Under investigation.',
        involvedASNs: ['AS64512', 'AS174'] 
    },
    { 
        id: 'evt-resolution-1', 
        timestamp: new Date(Date.now() - 48 * 3600 * 1000).toISOString(), // 2 days ago
        date: new Date(Date.now() - 48 * 3600 * 1000).toLocaleDateString(),
        time: new Date(Date.now() - 48 * 3600 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: 'resolution', 
        severity: 'info', 
        description: 'Previous routing anomaly affecting AS15169 (Google) has been resolved. Path stability restored.',
        involvedASNs: ['AS15169'] 
    },
    { 
        id: 'evt-newpeer-1', 
        timestamp: new Date(Date.now() - 72 * 3600 * 1000).toISOString(), // 3 days ago
        date: new Date(Date.now() - 72 * 3600 * 1000).toLocaleDateString(),
        time: new Date(Date.now() - 72 * 3600 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: 'new_peer', 
        severity: 'info', 
        description: 'New peering agreement established between AS13335 (Cloudflare) and AS32934 (Facebook).',
        involvedASNs: ['AS13335', 'AS32934'] 
    },
     { 
        id: 'evt-hijack-resolved-1', 
        timestamp: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(), // 5 days ago
        date: new Date(Date.now() - 5 * 24 * 3600 * 1000).toLocaleDateString(), 
        time: new Date(Date.now() - 5 * 24 * 3600 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), 
        type: 'resolution', 
        severity: 'info', 
        description: 'Previously reported hijack by AS-BADACTOR targeting AS-VICTIM has been mitigated. Routes are now stable.',
        involvedASNs: ['AS-BADACTOR', 'AS-VICTIM'] 
    },
    { 
        id: 'evt-policychange-1', 
        timestamp: new Date(Date.now() - 10 * 24 * 3600 * 1000).toISOString(), // 10 days ago
        date: new Date(Date.now() - 10 * 24 * 3600 * 1000).toLocaleDateString(),
        time: new Date(Date.now() - 10 * 24 * 3600 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        type: 'policy_change', 
        severity: 'info', 
        description: 'AS174 (Cogent) updated its routing policy. No major impact observed on global routing tables.',
        involvedASNs: ['AS174'] 
    }
];
