

export type RPKIStatus = 'valid' | 'invalid' | 'unknown' | 'unverified';

export interface ASNNode {
  id: string; // ASN, e.g., "AS13335"
  name: string; // Common name, e.g., "Cloudflare"
  threat: 'critical' | 'high' | 'medium' | 'low' | 'clean' | 'unknown';
  country: string; // Two-letter country code, e.g., "US"
  org: string; // Organization name
  tier: number; // Network tier (1, 2, 3)
  customers: number; // Estimated number of customers/downstreams
  x?: number; // D3 position
  y?: number; // D3 position
  vx?: number; // D3 velocity
  vy?: number; // D3 velocity
  fx?: number | null; // D3 fixed position
  fy?: number | null; // D3 fixed position
  index?: number; // D3 simulation index
}

export interface BGPLink {
  source: string | ASNNode; // ASN ID or node object
  target: string | ASNNode; // ASN ID or node object
  type: 'transit' | 'peer' | 'leak' | 'hijack' | 'geopolitical' | 'unknown';
  suspicious: boolean;
  bandwidth?: string; // e.g., "100G"
  established?: string; // Date string, e.g., "2015-03-15"
  geopolitical?: boolean; // True if link has geopolitical implications
  id?: string; // Optional unique ID for React keys if source/target not enough
}

// Represents a BGPLink where source and target have been resolved to ASNNode objects
export type ResolvedBGPLink = Omit<BGPLink, 'source' | 'target'> & {
  source: ASNNode;
  target: ASNNode;
};

export interface ThreatLegendItem {
  level: ASNNode['threat'];
  label: string;
  colorClass: string;
}

export interface LinkLegendItem {
    type: BGPLink['type'] | 'hijack-display' | 'leak-display'; // Use distinct types for legend display if needed
    label: string;
    colorClass: string; // Tailwind text color e.g. text-red-600
    lineStyle: string; // Description like '━━', '┈┈'
}

export interface AnalysisHistoryItem {
  id: string;
  query: string;
  timestamp: number;
}

export enum LayoutMode {
  Force = "force",
  Radial = "radial",
  Hierarchical = "hierarchical",
  Geographical = "geographical",
}

export interface FeedEntryMessage {
  id: string;
  timestamp: string;
  text: string;
  type: 'info' | 'warning' | 'error' | 'success' | 'critical-alert';
}

export interface ThreatSummaryData {
  id: string;
  asn: string;
  org: string;
  country: string;
  score: number; // 0-100
  threatLevel: ASNNode['threat'];
  description: string;
  relatedEvents: number;
  geminiAnalysis?: string; // Optional, as it's fetched on demand
  isGeminiAnalyzing?: boolean; // To show loading state
}

export interface HistoricalEvent {
  id: string;
  timestamp: string; // ISO date string
  date: string; // Formatted date
  time: string; // Formatted time
  type: 'hijack' | 'leak' | 'resolution' | 'new_peer' | 'policy_change' | 'security_incident';
  severity: 'critical' | 'warning' | 'info';
  description: string;
  involvedASNs: string[];
}

export interface ASPathSegment {
  asn: string;
  org: string;
  country: string;
  isRpkiValid?: boolean;
  isSuspectedHijacker?: boolean;
}

export interface ASPathData {
  id: string;
  sourceAS: string; // Starting ASN of the path (can be different from query source)
  destinationPrefix: string; // The prefix this path is for
  path: ASPathSegment[];
  isPotentiallyHijacked: boolean;
  isRouteLeak: boolean;
}

export interface GeopoliticalInfo {
  id: string;
  asn: string;
  country: string;
  riskFactor: 'high' | 'medium' | 'low';
  details: string;
  relatedLinks: { source: string; target: string; reason: string }[];
}

export interface TooltipData {
  visible: boolean;
  content: string;
  x: number;
  y: number;
  asn?: ASNNode;
}

export interface ASNPairAnalysisResult {
  sourceNode?: ASNNode;
  destinationNode?: ASNNode;
  directLinks?: ResolvedBGPLink[];
  paths?: ASPathData[];
  error?: string;
  timestamp?: number; // To help React re-render if the same query is made
}

export interface BGPUpdateEvent {
  id: string;
  timestamp: string; // ISO string
  type: 'new_hijack' | 'new_leak' | 'prefix_update' | 'new_peering' | 'peering_down' | 'rpki_status_change' | 'general_update' | 'hijack_resolved' | 'leak_resolved';
  description: string;
  severity: FeedEntryMessage['type'];
  // For new_hijack, new_leak, new_peering, peering_down, sourceAS is attacker/leaker/peer1, targetAS is victim/affected/peer2
  // For hijack_resolved, leak_resolved, sourceAS can be the original hijacker/leaker, targetAS the victim.
  sourceAS?: string;
  targetAS?: string;
  // For rpki_status_change, prefix_update, general_update
  relatedASNs?: string[];
  prefix?: string;
  newRpkiStatus?: 'valid' | 'invalid' | 'unknown'; // for rpki_status_change
  oldRpkiStatus?: 'valid' | 'invalid' | 'unknown'; // for rpki_status_change
}

// For ASNDetailView
export interface AnnouncedPrefixInfo {
  prefix: string;
  description: string;
  rpkiStatus: RPKIStatus;
  originAS: string; // ASN originating this prefix announcement
}

export interface KeyPeerInfo {
  asnId: string;
  org: string;
  country: string;
  relationshipType: 'Transit Provider' | 'Customer' | 'Private Peer' | 'Public Peer' | 'Sibling' | 'Unknown';
  connectionSince?: string; // ISO Date
  bandwidth?: string;
}

export interface RecentBGPActivityInfo {
  timestamp: string; // ISO Date
  type: BGPUpdateEvent['type'] | HistoricalEvent['type'];
  summary: string;
  relatedPrefix?: string;
  relatedASNs?: string[];
}

export interface ASNDetailedInfo {
  asn: ASNNode; // Core ASN data
  announcedPrefixes: AnnouncedPrefixInfo[];
  keyPeers: KeyPeerInfo[];
  recentBGPActivity: RecentBGPActivityInfo[];
  connectivityScore: number; // 0-100
  securityPostureScore: number; // 0-100, based on RPKI, known threats etc.
  isGeminiAnalyzing?: boolean;
  geminiAnalysis?: string;
  lastUpdated: string; // ISO date string
}
